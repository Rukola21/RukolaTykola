# NoteVault — Пошаговая инструкция по сборке

## Шаг 1 — Открыть проект в Android Studio

1. Скачай и распакуй `NoteVault.zip`
2. Открой Android Studio (Hedgehog 2023.1.1 или новее)
3. `File → Open` → выбери папку `NoteVault`
4. Подожди синхронизацию Gradle (первый раз ~3–5 мин)

---

## Шаг 2 — Переименовать финальные файлы

В проекте некоторые файлы имеют суффикс `Final` или `V2` — это финальные версии.
Нужно заменить исходные файлы финальными:

```
# Файлы которые ЗАМЕНИТЬ (удали старый, оставь финальный):

data/local/dao/AttachmentDao.kt        ← заменить на AttachmentDaoV2.kt
data/repository/NoteRepository.kt     ← заменить на NoteRepositoryV2.kt
utils/FileUtils.kt                     ← заменить на FileUtilsV2.kt
utils/AppPreferences.kt               ← заменить на AppPreferencesFinal.kt
ui/notes/NoteListFragment.kt          ← заменить на NoteListFragmentFinal.kt
ui/notes/NoteListViewModel.kt         ← заменить на NoteListViewModelFinal.kt
ui/notes/NoteAdapter.kt               ← заменить на NoteAdapterFinal.kt
ui/editor/NoteEditorFragment.kt       ← заменить на NoteEditorFragmentV2.kt
ui/settings/SettingsViewModel.kt      ← заменить на SettingsViewModelV2.kt
telegram/TelegramBotService.kt        ← заменить на TelegramBotServiceFinal.kt
app/build.gradle                      ← заменить на build_v2.gradle
res/layout/fragment_note_list.xml     ← заменить на fragment_note_list_final.xml

# Удалить вспомогательные файлы:
ui/notes/NavDirections_README.kt
ui/settings/SettingsViewModelV2.kt (переименовать → SettingsViewModel.kt)
```

**Быстрый способ в Android Studio:**
- Правый клик на файл → Refactor → Rename → убери суффикс Final/V2

---

## Шаг 3 — Добавить иконку приложения

В Android Studio:
1. Right-click на `res` → `New → Image Asset`
2. Icon Type: `Launcher Icons (Adaptive and Legacy)`
3. Foreground Layer: выбери `@drawable/ic_launcher_foreground`
4. Background Layer: Color → `#FFECDF`
5. Next → Finish

---

## Шаг 4 — Sync и проверка

```
File → Sync Project with Gradle Files
Build → Make Project
```

Если ошибки:
- `Unresolved reference: NoteListFragmentDirections` → убедись что Safe Args плагин добавлен в оба build.gradle
- `Cannot find symbol @HiltAndroidApp` → добавь Hilt плагин и пересинхронизируй
- `Room schema export error` → добавь в `defaultConfig`: `javaCompileOptions { annotationProcessorOptions { arguments["room.schemaLocation"] = "$projectDir/schemas" } }`

---

## Шаг 5 — Запуск на устройстве

1. Подключи Android телефон через USB (Android 8.0+)
2. Включи `Параметры разработчика → Отладка по USB`
3. В Android Studio выбери своё устройство в списке
4. Нажми `Run ▶`

---

## Шаг 6 — Настройка Telegram бота

1. Открой [@BotFather](https://t.me/BotFather) в Telegram
2. Отправь `/newbot` → введи название и username бота
3. Скопируй токен вида `6428391234:AAF3mK...`
4. В приложении: **Настройки → вставь токен → Сохранить токен**
5. Включи переключатель **"Бот активен"**
6. Напиши своему боту `/start` — он сохранит Chat ID автоматически
7. Готово! Теперь пересылай боту любые сообщения из Telegram

---

## Возможные проблемы

| Проблема | Решение |
|----------|---------|
| Бот не отвечает | Проверь интернет, токен, что переключатель включён |
| Фото не сохраняется | Проверь разрешения READ_MEDIA_IMAGES в настройках приложения |
| Камера не открывается | Выдай разрешение CAMERA в настройках приложения |
| Файлы не прикрепляются | Выдай разрешение READ_EXTERNAL_STORAGE |
| Бот останавливается | На некоторых телефонах (Xiaomi, Huawei) надо отключить "оптимизацию батареи" для NoteVault |

---

## Структура файлов в `internal storage`

```
/data/data/com.notevault/files/
├── notes/
│   ├── note_1/
│   │   ├── photo_123.jpg       ← оригинальные файлы
│   │   └── document.pdf
│   └── note_2/
│       └── voice_456.ogg
└── thumbs/
    └── note_1/
        └── thumb_photo_123.jpg ← превью (256×256)
```

Файлы хранятся в **Internal Storage** — они доступны только приложению
и не видны в галерее/файловом менеджере без root.
При удалении приложения все файлы удаляются автоматически.

---

## Добавление новых функций (идеи)

```kotlin
// 1. Напоминания по заметкам
WorkManager.getInstance(context)
    .enqueue(OneTimeWorkRequestBuilder<ReminderWorker>()
        .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
        .setInputData(workDataOf("note_id" to noteId))
        .build())

// 2. Экспорт заметки в PDF
val pdfDoc = PdfDocument()
val page = pdfDoc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
// рисуем контент...
pdfDoc.finishPage(page)
pdfDoc.writeTo(FileOutputStream(outputFile))

// 3. OCR из изображения (ML Kit)
val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
recognizer.process(InputImage.fromFilePath(context, imageUri))
    .addOnSuccessListener { result -> /* result.text */ }

// 4. Синхронизация с Google Drive
val driveService = Drive.Builder(transport, jsonFactory, credential)
    .setApplicationName("NoteVault").build()
```
