package com.notevault.ui.editor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.notevault.R

class NoteColorPickerDialog(
    private val currentColor: Int,
    private val onColorSelected: (Int) -> Unit
) : BottomSheetDialogFragment() {

    private val colors = listOf(
        R.color.note_default,
        R.color.note_red,
        R.color.note_orange,
        R.color.note_yellow,
        R.color.note_green,
        R.color.note_blue,
        R.color.note_purple
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        val root = inflater.inflate(R.layout.dialog_color_picker, container, false)
        val row = root.findViewById<ViewGroup>(R.id.colorRow)

        colors.forEachIndexed { index, colorRes ->
            val circle = ImageView(requireContext()).apply {
                val size = resources.getDimensionPixelSize(R.dimen.color_circle_size)
                layoutParams = ViewGroup.MarginLayoutParams(size, size).apply {
                    marginEnd = resources.getDimensionPixelSize(R.dimen.color_circle_margin)
                }
                setImageResource(R.drawable.bg_color_circle)
                imageTintList = ContextCompat.getColorStateList(requireContext(), colorRes)
                // Подчёркиваем текущий выбор
                if (index == currentColor) {
                    scaleX = 1.3f
                    scaleY = 1.3f
                }
                setOnClickListener {
                    onColorSelected(index)
                    dismiss()
                }
            }
            row.addView(circle)
        }
        return root
    }

    companion object {
        const val TAG = "NoteColorPickerDialog"
    }
}
