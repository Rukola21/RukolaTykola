package com.notevault.data.repository

import android.content.Context
import android.net.Uri
import com.notevault.data.local.dao.AttachmentDao
import com.notevault.data.local.dao.NoteDao
import com.notevault.data.local.entities.Attachment
import com.notevault.data.local.entities.AttachmentType
import com.notevault.data.local.entities.Note
import com.notevault.utils.FileUtils
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import java.time.LocalDateTime
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NoteRepository @Inject constructor(
    private val noteDao: NoteDao,
    private val attachmentDao: AttachmentDao,
    private val fileUtils: FileUtils,
    @ApplicationContext private val context: Context
) {
    // ─── Notes ──────────────────────────────────────────────────────────────

    fun getAllNotes(): Flow<List<Note>> = noteDao.getAllNotes()

    fun searchNotes(query: String): Flow<List<Note>> = noteDao.searchNotes(query)

    fun getNotesByTag(tag: String): Flow<List<Note>> = noteDao.getNotesByTag(tag)

    suspend fun getNoteById(id: Long): Note? = noteDao.getNoteById(id)

    suspend fun getRecentNotes(limit: Int = 5): List<Note> = noteDao.getRecentNotes(limit)

    suspend fun getNotesCount(): Int = noteDao.getNotesCount()

    suspend fun createNote(
        title: String = "",
        content: String = "",
        tags: List<String> = emptyList(),
        color: Int = 0,
        telegramMessageId: Long? = null,
        telegramChatId: Long? = null
    ): Long {
        val note = Note(
            title = title,
            content = content,
            tags = if (tags.isEmpty()) "" else
                tags.joinToString(",", "[", "]") { "\"$it\"" },
            color = color,
            telegramMessageId = telegramMessageId,
            telegramChatId = telegramChatId
        )
        return noteDao.insertNote(note)
    }

    suspend fun updateNote(note: Note) {
        noteDao.updateNote(note.copy(updatedAt = LocalDateTime.now()))
    }

    suspend fun deleteNote(note: Note) {
        noteDao.deleteNote(note)
        // Room CASCADE удалит Attachment записи,
        // но нам нужно удалить файлы с диска
        fileUtils.deleteNoteDirectory(note.id)
    }

    suspend fun togglePin(noteId: Long, pinned: Boolean) =
        noteDao.setPinned(noteId, pinned)

    // ─── Attachments ─────────────────────────────────────────────────────────

    fun getAttachmentsForNote(noteId: Long): Flow<List<Attachment>> =
        attachmentDao.getAttachmentsForNote(noteId)

    suspend fun addAttachmentFromUri(noteId: Long, uri: Uri): Attachment? {
        return fileUtils.copyFileToInternal(uri, noteId)?.let { savedFile ->
            val attachment = Attachment(
                noteId = noteId,
                fileName = savedFile.name,
                localPath = savedFile.absolutePath,
                mimeType = fileUtils.getMimeType(uri) ?: "application/octet-stream",
                type = fileUtils.detectAttachmentType(uri),
                size = savedFile.length(),
                width = fileUtils.getImageWidth(savedFile.absolutePath),
                height = fileUtils.getImageHeight(savedFile.absolutePath),
                thumbnailPath = fileUtils.createThumbnail(savedFile, noteId)?.absolutePath
            )
            val id = attachmentDao.insertAttachment(attachment)
            attachment.copy(id = id)
        }
    }

    suspend fun addAttachmentFromBytes(
        noteId: Long,
        bytes: ByteArray,
        fileName: String,
        mimeType: String,
        telegramFileId: String? = null
    ): Attachment? {
        return fileUtils.saveBytesToInternal(bytes, fileName, noteId)?.let { savedFile ->
            val type = fileUtils.detectTypeFromMime(mimeType)
            val attachment = Attachment(
                noteId = noteId,
                fileName = fileName,
                localPath = savedFile.absolutePath,
                mimeType = mimeType,
                type = type,
                size = savedFile.length(),
                width = if (type == AttachmentType.IMAGE) fileUtils.getImageWidth(savedFile.absolutePath) else null,
                height = if (type == AttachmentType.IMAGE) fileUtils.getImageHeight(savedFile.absolutePath) else null,
                thumbnailPath = if (type == AttachmentType.IMAGE)
                    fileUtils.createThumbnail(savedFile, noteId)?.absolutePath else null,
                telegramFileId = telegramFileId
            )
            val id = attachmentDao.insertAttachment(attachment)
            attachment.copy(id = id)
        }
    }

    suspend fun deleteAttachment(attachment: Attachment) {
        fileUtils.deleteFile(attachment.localPath)
        attachment.thumbnailPath?.let { fileUtils.deleteFile(it) }
        attachmentDao.deleteAttachment(attachment)
    }

    suspend fun getTotalStorageUsed(): Long =
        attachmentDao.getTotalStorageUsed() ?: 0L
}
