package com.notevault.ui.notes

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.notevault.R
import com.notevault.data.local.entities.Note
import com.notevault.databinding.ItemNoteGridBinding
import com.notevault.databinding.ItemNoteListBinding
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

class NoteAdapter(
    private val onNoteClick: (Note) -> Unit,
    private val onNoteLongClick: (Note) -> Unit
) : ListAdapter<Note, RecyclerView.ViewHolder>(DiffCallback) {

    private var viewMode = "grid"

    companion object {
        private const val VIEW_GRID = 0
        private const val VIEW_LIST = 1
        private val DATE_FMT = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)
    }

    fun setViewMode(mode: String) {
        viewMode = mode
        notifyItemRangeChanged(0, itemCount)
    }

    override fun getItemViewType(position: Int) =
        if (viewMode == "grid") VIEW_GRID else VIEW_LIST

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_GRID) {
            GridViewHolder(ItemNoteGridBinding.inflate(
                LayoutInflater.from(parent.context), parent, false))
        } else {
            ListViewHolder(ItemNoteListBinding.inflate(
                LayoutInflater.from(parent.context), parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val note = getItem(position)
        when (holder) {
            is GridViewHolder -> holder.bind(note)
            is ListViewHolder -> holder.bind(note)
        }
    }

    inner class GridViewHolder(private val b: ItemNoteGridBinding)
        : RecyclerView.ViewHolder(b.root) {

        fun bind(note: Note) {
            b.tvTitle.text = note.title.ifBlank { "Без названия" }
            b.tvContent.text = note.content.take(200)
            b.tvDate.text = note.updatedAt.format(DATE_FMT)
            b.ivPin.visibility = if (note.isPinned) View.VISIBLE else View.GONE
            b.tvTelegramBadge.visibility =
                if (note.telegramChatId != null) View.VISIBLE else View.GONE

            // Цвет заметки
            val colors = b.root.context.resources.obtainTypedArray(R.array.note_colors)
            b.cardView.setCardBackgroundColor(colors.getColor(
                note.color.coerceIn(0, colors.length() - 1), 0))
            colors.recycle()

            b.root.setOnClickListener { onNoteClick(note) }
            b.root.setOnLongClickListener { onNoteLongClick(note); true }
        }
    }

    inner class ListViewHolder(private val b: ItemNoteListBinding)
        : RecyclerView.ViewHolder(b.root) {

        fun bind(note: Note) {
            b.tvTitle.text = note.title.ifBlank { "Без названия" }
            b.tvContent.text = note.content.take(120)
            b.tvDate.text = note.updatedAt.format(DATE_FMT)
            b.ivPin.visibility = if (note.isPinned) View.VISIBLE else View.GONE

            b.root.setOnClickListener { onNoteClick(note) }
            b.root.setOnLongClickListener { onNoteLongClick(note); true }
        }
    }

    object DiffCallback : DiffUtil.ItemCallback<Note>() {
        override fun areItemsTheSame(oldItem: Note, newItem: Note) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Note, newItem: Note) = oldItem == newItem
    }
}
