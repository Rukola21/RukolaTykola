package com.notevault

import android.app.Application
import com.notevault.telegram.TelegramBotService
import com.notevault.utils.AppPreferences
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class NoteVaultApp : Application() {

    @Inject
    lateinit var prefs: AppPreferences

    override fun onCreate() {
        super.onCreate()

        // Автозапуск Telegram бота при старте приложения
        if (prefs.botEnabled && prefs.telegramBotToken.isNotBlank()) {
            TelegramBotService.start(this)
        }
    }
}
