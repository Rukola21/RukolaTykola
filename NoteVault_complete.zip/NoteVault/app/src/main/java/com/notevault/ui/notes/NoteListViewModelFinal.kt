package com.notevault.ui.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notevault.data.local.entities.Note
import com.notevault.data.repository.NoteRepository
import com.notevault.utils.AppPreferences
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
@HiltViewModel
class NoteListViewModel @Inject constructor(
    private val repository: NoteRepository,
    private val prefs: AppPreferences
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedTag = MutableStateFlow<String?>(null)
    val selectedTag = _selectedTag.asStateFlow()

    val notes: StateFlow<List<Note>> = combine(_searchQuery.debounce(200), _selectedTag) { q, tag ->
        q to tag
    }.flatMapLatest { (query, tag) ->
        when {
            query.isNotBlank() -> repository.searchNotes(query)
            tag != null        -> repository.getNotesByTag(tag)
            else               -> repository.getAllNotes()
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Все уникальные теги из всех заметок (для отображения фильтр-чипов) */
    val allTags: StateFlow<List<String>> = repository.getAllNotes()
        .map { notes ->
            notes.flatMap { it.getTagsList() }
                .groupingBy { it }
                .eachCount()
                .entries
                .sortedByDescending { it.value }
                .map { it.key }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notesViewMode: StateFlow<String> = prefs.notesViewFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "grid")

    fun search(query: String) { _searchQuery.value = query }

    fun filterByTag(tag: String?) { _selectedTag.value = tag }

    fun togglePin(note: Note) {
        viewModelScope.launch { repository.togglePin(note.id, !note.isPinned) }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch { repository.deleteNote(note) }
    }

    fun setViewMode(mode: String) {
        viewModelScope.launch { prefs.setNotesView(mode) }
    }
}
