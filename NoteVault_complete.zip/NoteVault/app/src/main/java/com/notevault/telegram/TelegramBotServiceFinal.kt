package com.notevault.telegram

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.notevault.R
import com.notevault.data.repository.NoteRepository
import com.notevault.ui.MainActivity
import com.notevault.utils.AppPreferences
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import javax.inject.Inject

@AndroidEntryPoint
class TelegramBotService : Service() {

    @Inject lateinit var repository: NoteRepository
    @Inject lateinit var prefs: AppPreferences

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(35, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private var botToken = ""
    private var allowedChatId = 0L
    private var isPolling = false

    // Буфер для групп медиа (альбомов в Telegram)
    // media_group_id → (noteId, список file_id)
    private val mediaGroupBuffer = mutableMapOf<String, Long>()

    companion object {
        const val CHANNEL_ID  = "tg_bot_service"
        const val NOTIF_ID    = 9001
        const val NOTES_CHANNEL = "notes_incoming"
        private const val TAG = "TGBotService"

        fun start(context: Context) =
            context.startForegroundService(Intent(context, TelegramBotService::class.java))

        fun stop(context: Context) =
            context.stopService(Intent(context, TelegramBotService::class.java))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannels()
        startForeground(NOTIF_ID, buildServiceNotif("Слушаю Telegram..."))

        botToken       = prefs.telegramBotToken
        allowedChatId  = prefs.telegramChatId

        if (botToken.isBlank()) { stopSelf(); return START_NOT_STICKY }

        startPolling()
        return START_STICKY
    }

    // ── Long Polling ─────────────────────────────────────────────────────────

    private fun startPolling() {
        if (isPolling) return
        isPolling = true
        scope.launch {
            while (isPolling) {
                try { poll() } catch (e: Exception) { Log.e(TAG, "poll error", e) }
                delay(1_500)
            }
        }
    }

    private suspend fun poll() {
        val offset = prefs.lastUpdateId + 1
        val url = "https://api.telegram.org/bot$botToken/getUpdates?offset=$offset&timeout=30&limit=10"
        val resp = get(url) ?: return
        val json = JSONObject(resp)
        if (!json.getBoolean("ok")) return
        val updates = json.getJSONArray("result")
        for (i in 0 until updates.length()) {
            val upd = updates.getJSONObject(i)
            val uid = upd.getLong("update_id")
            prefs.lastUpdateId = uid
            processUpdate(upd)
        }
    }

    // ── Update Processing ─────────────────────────────────────────────────────

    private suspend fun processUpdate(update: JSONObject) {
        val msg = update.optJSONObject("message") ?: return
        val chatId = msg.getJSONObject("chat").getLong("id")
        val msgId  = msg.getLong("message_id")
        val text   = msg.optString("text", "")

        // Проверяем авторизацию
        if (allowedChatId != 0L && chatId != allowedChatId) {
            send(chatId, "⛔ Нет доступа.")
            return
        }

        // Команды
        when {
            text.startsWith("/start") -> handleStart(chatId)
            text.startsWith("/help")  -> handleHelp(chatId)
            text.startsWith("/list")  -> handleList(chatId)
            text.startsWith("/stats") -> handleStats(chatId)
            else -> handleContent(msg, chatId, msgId)
        }
    }

    // ── Commands ──────────────────────────────────────────────────────────────

    private suspend fun handleStart(chatId: Long) {
        if (allowedChatId == 0L) {
            prefs.setChatId(chatId)
            allowedChatId = chatId
            send(chatId, """
                🎉 *NoteVault Bot активирован!*
                
                Твой Chat ID: `$chatId` сохранён.
                
                Теперь пересылай мне что угодно:
                📝 Текст → заметка
                🖼 Фото → заметка с изображением  
                📎 Файл → заметка с вложением
                🎤 Голосовое → заметка с аудио
                📁 Альбом → одна заметка со всеми фото
                
                /help — подробная справка
            """.trimIndent())
        } else {
            send(chatId, "✅ Бот уже настроен. Chat ID: `$chatId`")
        }
    }

    private suspend fun handleHelp(chatId: Long) {
        send(chatId, """
            📒 *NoteVault Bot — справка*
            
            *Как сохранить заметку:*
            Просто пришли или перешли мне любое сообщение.
            
            *Поддерживаемые типы:*
            • Текст → текстовая заметка
            • Фото → заметка + изображение
            • Документ/файл → заметка + вложение
            • Голосовое → заметка + аудиофайл
            • Видео → заметка + видеофайл
            • Альбом (несколько фото) → одна заметка
            
            *Теги:* добавь #тег прямо в текст или подпись.
            
            *Команды:*
            /start — активация
            /list — последние 5 заметок
            /stats — статистика
            /help — эта справка
        """.trimIndent())
    }

    private suspend fun handleList(chatId: Long) {
        val notes = repository.getRecentNotes(5)
        if (notes.isEmpty()) { send(chatId, "📭 Заметок пока нет."); return }
        val sb = StringBuilder("📋 *Последние заметки:*\n\n")
        notes.forEachIndexed { i, n ->
            val title = n.title.ifBlank { n.content.take(40) }.ifBlank { "Без названия" }
            val date  = n.updatedAt.let { "${it.dayOfMonth}.${it.monthValue}.${it.year}" }
            sb.appendLine("${i + 1}. $title _($date)_")
        }
        send(chatId, sb.toString())
    }

    private suspend fun handleStats(chatId: Long) {
        val count   = repository.getNotesCount()
        val storage = repository.getTotalStorageUsed()
        val storageStr = when {
            storage < 1024 -> "$storage B"
            storage < 1048576 -> "${storage / 1024} KB"
            else -> "${"%.1f".format(storage / 1048576.0)} MB"
        }
        send(chatId, """
            📊 *Статистика NoteVault:*
            
            📝 Заметок: $count
            💾 Занято хранилище: $storageStr
        """.trimIndent())
    }

    // ── Content Handling ──────────────────────────────────────────────────────

    private suspend fun handleContent(msg: JSONObject, chatId: Long, msgId: Long) {
        val caption = msg.optString("caption", "")
        val text    = msg.optString("text", "")
        val body    = caption.ifBlank { text }

        // Извлекаем теги из текста (#тег)
        val extractedTags = Regex("#(\\w+)").findAll(body)
            .map { it.groupValues[1].lowercase() }
            .toMutableList()
            .also { it.add("telegram") }

        // Если это часть медиа-группы (альбома) — добавляем к существующей заметке
        val mediaGroupId = msg.optString("media_group_id", "")
        val noteId: Long = if (mediaGroupId.isNotEmpty() && mediaGroupBuffer.containsKey(mediaGroupId)) {
            mediaGroupBuffer[mediaGroupId]!!
        } else {
            val title = buildTitle(body, msgId)
            val id = repository.createNote(
                title = title,
                content = body,
                tags = extractedTags,
                telegramMessageId = msgId,
                telegramChatId = chatId
            )
            if (mediaGroupId.isNotEmpty()) mediaGroupBuffer[mediaGroupId] = id
            id
        }

        var attachCount = 0

        // Фото
        msg.optJSONArray("photo")?.let { photos ->
            val best = photos.getJSONObject(photos.length() - 1)
            downloadTelegramFile(best.getString("file_id"), noteId, "photo_${msgId}.jpg", "image/jpeg")
            attachCount++
        }

        // Документ
        msg.optJSONObject("document")?.let { doc ->
            downloadTelegramFile(
                doc.getString("file_id"), noteId,
                doc.optString("file_name", "file_$msgId"),
                doc.optString("mime_type", "application/octet-stream")
            )
            attachCount++
        }

        // Аудио
        msg.optJSONObject("audio")?.let { audio ->
            downloadTelegramFile(
                audio.getString("file_id"), noteId,
                audio.optString("file_name", "audio_$msgId.mp3"),
                "audio/mpeg"
            )
            attachCount++
        }

        // Голосовое
        msg.optJSONObject("voice")?.let { voice ->
            downloadTelegramFile(voice.getString("file_id"), noteId, "voice_$msgId.ogg", "audio/ogg")
            attachCount++
        }

        // Видео
        msg.optJSONObject("video")?.let { video ->
            downloadTelegramFile(
                video.getString("file_id"), noteId,
                video.optString("file_name", "video_$msgId.mp4"),
                "video/mp4"
            )
            attachCount++
        }

        // Стикер (сохраняем как изображение)
        msg.optJSONObject("sticker")?.let { sticker ->
            downloadTelegramFile(sticker.getString("file_id"), noteId, "sticker_$msgId.webp", "image/webp")
            attachCount++
        }

        val suffix = if (attachCount > 0) " + $attachCount вложени${
            when { attachCount == 1 -> "е"; attachCount in 2..4 -> "я"; else -> "й" }
        }" else ""
        send(chatId, "✅ Сохранено$suffix!")

        // Уведомление в статусбаре только для первого сообщения альбома
        if (mediaGroupId.isEmpty() || !mediaGroupBuffer.containsKey(mediaGroupId)) {
            showIncomingNotification(
                title = buildTitle(body, msgId),
                noteId = noteId
            )
        }
    }

    private fun buildTitle(body: String, msgId: Long): String {
        val firstLine = body.lines().firstOrNull { it.isNotBlank() }?.take(60)
        return firstLine ?: "Из Telegram #$msgId"
    }

    // ── Telegram File Download ────────────────────────────────────────────────

    private suspend fun downloadTelegramFile(
        fileId: String, noteId: Long, fileName: String, mimeType: String
    ) {
        try {
            val infoJson = JSONObject(
                get("https://api.telegram.org/bot$botToken/getFile?file_id=$fileId") ?: return
            )
            if (!infoJson.getBoolean("ok")) return
            val path = infoJson.getJSONObject("result").getString("file_path")

            val bytes = getRaw("https://api.telegram.org/file/bot$botToken/$path") ?: return
            repository.addAttachmentFromBytes(noteId, bytes, fileName, mimeType, fileId)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to download file $fileId", e)
        }
    }

    // ── HTTP helpers ──────────────────────────────────────────────────────────

    private suspend fun get(url: String): String? = withContext(Dispatchers.IO) {
        try {
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (r.isSuccessful) r.body?.string() else null
            }
        } catch (e: Exception) { Log.e(TAG, "GET $url failed", e); null }
    }

    private suspend fun getRaw(url: String): ByteArray? = withContext(Dispatchers.IO) {
        try {
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (r.isSuccessful) r.body?.bytes() else null
            }
        } catch (e: Exception) { Log.e(TAG, "GET_RAW $url failed", e); null }
    }

    private suspend fun send(chatId: Long, text: String) {
        try {
            val body = JSONObject().apply {
                put("chat_id", chatId)
                put("text", text)
                put("parse_mode", "Markdown")
            }.toString().toRequestBody("application/json".toMediaType())
            withContext(Dispatchers.IO) {
                client.newCall(
                    Request.Builder()
                        .url("https://api.telegram.org/bot$botToken/sendMessage")
                        .post(body)
                        .build()
                ).execute().close()
            }
        } catch (e: Exception) { Log.e(TAG, "send() failed", e) }
    }

    // ── Notifications ─────────────────────────────────────────────────────────

    private fun showIncomingNotification(title: String, noteId: Long) {
        val pi = PendingIntent.getActivity(
            this, noteId.toInt(),
            Intent(this, MainActivity::class.java).apply {
                putExtra("open_note_id", noteId)
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(this, NOTES_CHANNEL)
            .setSmallIcon(R.drawable.ic_telegram)
            .setContentTitle("Новая заметка из Telegram")
            .setContentText(title)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        getSystemService(NotificationManager::class.java)
            .notify(noteId.toInt(), notif)
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Telegram Bot сервис",
                NotificationManager.IMPORTANCE_LOW)
                .apply { description = "Работает в фоне для получения заметок" }
        )
        nm.createNotificationChannel(
            NotificationChannel(NOTES_CHANNEL, "Входящие заметки",
                NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun buildServiceNotif(status: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NoteVault")
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_telegram)
            .setOngoing(true)
            .setSilent(true)
            .build()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isPolling = false
        scope.cancel()
    }
}
