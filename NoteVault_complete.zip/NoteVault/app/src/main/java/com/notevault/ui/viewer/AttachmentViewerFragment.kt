package com.notevault.ui.viewer

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.navArgs
import androidx.viewpager2.widget.ViewPager2
import com.notevault.databinding.FragmentAttachmentViewerBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.io.File

@AndroidEntryPoint
class AttachmentViewerFragment : Fragment() {

    private var _binding: FragmentAttachmentViewerBinding? = null
    private val binding get() = _binding!!
    private val args: AttachmentViewerFragmentArgs by navArgs()
    private val viewModel: AttachmentViewerViewModel by viewModels()
    private lateinit var pagerAdapter: AttachmentPagerAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAttachmentViewerBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        pagerAdapter = AttachmentPagerAdapter()
        binding.viewPager.adapter = pagerAdapter
        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                viewModel.selectAttachment(position)
            }
        })

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.attachments.collect { list ->
                        pagerAdapter.submitList(list)
                        binding.tvCounter.text = "${args.initialIndex + 1} / ${list.size}"
                        binding.viewPager.setCurrentItem(args.initialIndex, false)
                    }
                }
                launch {
                    viewModel.currentAttachment.collect { att ->
                        att ?: return@collect
                        binding.tvFileName.text = att.fileName
                        binding.tvFileSize.text = att.getReadableSize()
                    }
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(com.notevault.R.menu.menu_viewer, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            com.notevault.R.id.action_share -> {
                shareCurrentAttachment()
                true
            }
            com.notevault.R.id.action_open_with -> {
                openWithExternalApp()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun shareCurrentAttachment() {
        val att = viewModel.currentAttachment.value ?: return
        val file = File(att.localPath)
        val uri = FileProvider.getUriForFile(
            requireContext(),
            "${requireContext().packageName}.fileprovider",
            file
        )
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = att.mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Поделиться"
        ))
    }

    private fun openWithExternalApp() {
        val att = viewModel.currentAttachment.value ?: return
        val file = File(att.localPath)
        val uri = FileProvider.getUriForFile(
            requireContext(),
            "${requireContext().packageName}.fileprovider",
            file
        )
        startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, att.mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
