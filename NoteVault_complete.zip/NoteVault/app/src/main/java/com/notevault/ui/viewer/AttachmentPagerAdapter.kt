package com.notevault.ui.viewer

import android.media.MediaPlayer
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.notevault.R
import com.notevault.data.local.entities.Attachment
import com.notevault.data.local.entities.AttachmentType
import com.notevault.databinding.PageAttachmentImageBinding
import com.notevault.databinding.PageAttachmentFileBinding
import java.io.File

class AttachmentPagerAdapter :
    ListAdapter<Attachment, RecyclerView.ViewHolder>(DiffCb) {

    companion object {
        private const val TYPE_IMAGE = 0
        private const val TYPE_FILE  = 1
    }

    override fun getItemViewType(position: Int) =
        if (getItem(position).type == AttachmentType.IMAGE) TYPE_IMAGE else TYPE_FILE

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_IMAGE) {
            ImageVH(PageAttachmentImageBinding.inflate(inflater, parent, false))
        } else {
            FileVH(PageAttachmentFileBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val att = getItem(position)
        when (holder) {
            is ImageVH -> holder.bind(att)
            is FileVH  -> holder.bind(att)
        }
    }

    // ─── Image viewer ────────────────────────────────────────────────────────
    inner class ImageVH(private val b: PageAttachmentImageBinding) :
        RecyclerView.ViewHolder(b.root) {

        fun bind(att: Attachment) {
            Glide.with(b.ivImage)
                .load(File(att.localPath))
                .placeholder(R.drawable.ic_image_placeholder)
                .error(R.drawable.ic_image_placeholder)
                .into(b.ivImage)
        }
    }

    // ─── Generic file viewer ─────────────────────────────────────────────────
    inner class FileVH(private val b: PageAttachmentFileBinding) :
        RecyclerView.ViewHolder(b.root) {

        fun bind(att: Attachment) {
            b.tvFileName.text = att.fileName
            b.tvFileSize.text = att.getReadableSize()
            b.tvFileMime.text = att.mimeType

            val iconRes = when (att.type) {
                AttachmentType.VIDEO    -> R.drawable.ic_video
                AttachmentType.AUDIO    -> R.drawable.ic_audio
                AttachmentType.DOCUMENT -> R.drawable.ic_document
                else                    -> R.drawable.ic_file
            }
            b.ivFileIcon.setImageResource(iconRes)
        }
    }

    object DiffCb : DiffUtil.ItemCallback<Attachment>() {
        override fun areItemsTheSame(a: Attachment, b: Attachment) = a.id == b.id
        override fun areContentsTheSame(a: Attachment, b: Attachment) = a == b
    }
}
