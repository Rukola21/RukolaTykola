package com.notevault.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notevault.data.repository.NoteRepository
import com.notevault.utils.AppPreferences
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class SettingsEvent {
    object TokenSaved : SettingsEvent()
    data class Error(val message: String) : SettingsEvent()
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val prefs: AppPreferences,
    private val repository: NoteRepository
) : ViewModel() {

    val botToken: StateFlow<String> = prefs.botTokenFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    val chatId: StateFlow<Long> = prefs.chatIdFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val botEnabled: StateFlow<Boolean> = prefs.botEnabledFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val _events = MutableSharedFlow<SettingsEvent>()
    val events = _events.asSharedFlow()

    val storageUsed: StateFlow<Long> = flow {
        emit(repository.getTotalStorageUsed())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    fun saveBotToken(token: String) {
        viewModelScope.launch {
            try {
                prefs.setBotToken(token.trim())
                _events.emit(SettingsEvent.TokenSaved)
            } catch (e: Exception) {
                _events.emit(SettingsEvent.Error("Ошибка сохранения: ${e.message}"))
            }
        }
    }

    fun setBotEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setBotEnabled(enabled) }
    }
}
