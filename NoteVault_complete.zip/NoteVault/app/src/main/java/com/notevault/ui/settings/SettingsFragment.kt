package com.notevault.ui.settings

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.snackbar.Snackbar
import com.notevault.databinding.FragmentSettingsBinding
import com.notevault.telegram.TelegramBotService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupBotSection()
        observeViewModel()
    }

    private fun setupBotSection() {
        binding.btnSaveToken.setOnClickListener {
            val token = binding.etBotToken.text.toString().trim()
            if (token.isBlank()) {
                binding.tilBotToken.error = "Введи токен бота"
                return@setOnClickListener
            }
            viewModel.saveBotToken(token)
        }

        binding.btnOpenBotFather.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW,
                android.net.Uri.parse("https://t.me/BotFather")))
        }

        binding.switchBotEnabled.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setBotEnabled(isChecked)
            if (isChecked) {
                TelegramBotService.start(requireContext())
            } else {
                TelegramBotService.stop(requireContext())
            }
        }

        binding.btnCopyChatId.setOnClickListener {
            val chatId = binding.tvChatId.text.toString()
            val clipboard = requireContext().getSystemService(android.content.ClipboardManager::class.java)
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Chat ID", chatId))
            Snackbar.make(binding.root, "Chat ID скопирован", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.botToken.collect { token ->
                        if (binding.etBotToken.text.isNullOrEmpty() && token.isNotBlank()) {
                            binding.etBotToken.setText(maskToken(token))
                        }
                    }
                }
                launch {
                    viewModel.chatId.collect { id ->
                        binding.tvChatId.text = if (id == 0L) "Не получен (напиши боту /start)"
                        else id.toString()
                        binding.btnCopyChatId.isEnabled = id != 0L
                    }
                }
                launch {
                    viewModel.botEnabled.collect { enabled ->
                        binding.switchBotEnabled.isChecked = enabled
                        binding.tvBotStatus.text = if (enabled) "🟢 Бот активен" else "⚫ Бот выключен"
                    }
                }
                launch {
                    viewModel.storageUsed.collect { bytes ->
                        binding.tvStorageUsed.text = formatBytes(bytes)
                    }
                }
                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is SettingsEvent.TokenSaved ->
                                Snackbar.make(binding.root, "Токен сохранён!", Snackbar.LENGTH_SHORT).show()
                            is SettingsEvent.Error ->
                                Snackbar.make(binding.root, event.message, Snackbar.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
    }

    private fun maskToken(token: String): String {
        if (token.length < 10) return token
        return token.take(6) + "..." + token.takeLast(4)
    }

    private fun formatBytes(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            bytes < 1024 * 1024 * 1024 -> "${"%.1f".format(bytes / (1024.0 * 1024.0))} MB"
            else -> "${"%.2f".format(bytes / (1024.0 * 1024.0 * 1024.0))} GB"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
