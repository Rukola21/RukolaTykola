// Этот файл генерируется автоматически плагином Safe Args
// Добавь в build.gradle:
//   id 'androidx.navigation.safeargs.kotlin' version '2.7.6' apply false
// и в app/build.gradle:
//   id 'androidx.navigation.safeargs.kotlin'
//
// После этого NoteListFragmentDirections будет сгенерирован автоматически из nav_graph.xml
//
// Фрагмент навигации:
//   NoteListFragmentDirections.actionListToEditor(noteId = note.id)
//   NoteListFragmentDirections.actionListToEditor() // новая заметка
