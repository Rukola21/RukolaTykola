package com.notevault.telegram

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.gson.Gson
import com.notevault.R
import com.notevault.data.repository.NoteRepository
import com.notevault.ui.MainActivity
import com.notevault.utils.AppPreferences
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import javax.inject.Inject

@AndroidEntryPoint
class TelegramBotService : Service() {

    @Inject lateinit var repository: NoteRepository
    @Inject lateinit var prefs: AppPreferences

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val client = OkHttpClient()
    private val gson = Gson()

    private var botToken = ""
    private var allowedChatId = 0L
    private var lastUpdateId = 0L
    private var isPolling = false

    companion object {
        const val CHANNEL_ID = "telegram_bot_channel"
        const val NOTIF_ID = 1001
        private const val TAG = "TelegramBotService"
        private const val POLL_INTERVAL_MS = 2000L

        fun start(context: Context) {
            val intent = Intent(context, TelegramBotService::class.java)
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, TelegramBotService::class.java))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Ожидание сообщений..."))

        botToken = prefs.telegramBotToken
        allowedChatId = prefs.telegramChatId
        lastUpdateId = prefs.lastUpdateId

        if (botToken.isBlank()) {
            Log.w(TAG, "Bot token not set, stopping service")
            stopSelf()
            return START_NOT_STICKY
        }

        startPolling()
        return START_STICKY
    }

    private fun startPolling() {
        if (isPolling) return
        isPolling = true

        scope.launch {
            Log.i(TAG, "Telegram bot polling started")
            while (isPolling && botToken.isNotBlank()) {
                try {
                    pollUpdates()
                } catch (e: Exception) {
                    Log.e(TAG, "Polling error", e)
                }
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    /**
     * Запрашиваем обновления у Telegram Bot API (long polling)
     */
    private suspend fun pollUpdates() {
        val url = "https://api.telegram.org/bot$botToken/getUpdates" +
            "?offset=${lastUpdateId + 1}&timeout=30&limit=10"

        val request = Request.Builder().url(url).build()
        val response = withContext(Dispatchers.IO) {
            client.newCall(request).execute()
        }

        if (!response.isSuccessful) return
        val body = response.body?.string() ?: return
        val json = JSONObject(body)

        if (!json.getBoolean("ok")) return

        val updates = json.getJSONArray("result")
        for (i in 0 until updates.length()) {
            val update = updates.getJSONObject(i)
            val updateId = update.getLong("update_id")
            if (updateId > lastUpdateId) {
                lastUpdateId = updateId
                prefs.lastUpdateId = lastUpdateId
            }

            processUpdate(update)
        }
    }

    /**
     * Обрабатываем входящее сообщение от Telegram
     */
    private suspend fun processUpdate(update: JSONObject) {
        val message = update.optJSONObject("message") ?: return
        val chatId = message.getJSONObject("chat").getLong("id")
        val messageId = message.getLong("message_id")

        // Проверяем, что сообщение от нашего пользователя
        if (allowedChatId != 0L && chatId != allowedChatId) {
            sendMessage(chatId, "⛔ Доступ запрещён.")
            return
        }

        // Команды
        val text = message.optString("text", "")
        when {
            text.startsWith("/start") -> {
                if (allowedChatId == 0L) {
                    prefs.telegramChatId = chatId
                    allowedChatId = chatId
                    sendMessage(chatId, """
                        ✅ NoteVault бот активирован!
                        Твой Chat ID: $chatId — сохранён в приложении.
                        
                        Теперь пересылай мне:
                        📝 Текст → сохранится как заметка
                        🖼 Фото → сохранится с превью
                        📎 Файл → прикрепится к заметке
                        
                        Или просто перешли любое сообщение из другого чата!
                    """.trimIndent())
                } else {
                    sendMessage(chatId, "✅ Бот уже настроен! Chat ID: $chatId")
                }
            }

            text.startsWith("/help") -> {
                sendMessage(chatId, """
                    📒 *NoteVault Bot* помощь:
                    
                    Пришли мне:
                    • Текст → новая заметка
                    • Фото → заметка с изображением
                    • Файл → заметка с вложением
                    • Несколько медиа подряд → одна заметка с альбомом
                    
                    Команды:
                    /start — инициализация
                    /list — последние 5 заметок
                    /help — эта справка
                """.trimIndent())
            }

            text.startsWith("/list") -> {
                val notes = repository.getRecentNotes(5)
                if (notes.isEmpty()) {
                    sendMessage(chatId, "📭 Заметок пока нет.")
                } else {
                    val sb = StringBuilder("📋 *Последние заметки:*\n\n")
                    notes.forEachIndexed { i, note ->
                        val title = note.title.ifBlank { note.content.take(30) + "..." }
                        sb.appendLine("${i + 1}. $title")
                    }
                    sendMessage(chatId, sb.toString())
                }
            }

            else -> handleContentMessage(message, chatId, messageId)
        }
    }

    /**
     * Обрабатываем сообщение с контентом (текст, фото, файл)
     */
    private suspend fun handleContentMessage(
        message: JSONObject,
        chatId: Long,
        messageId: Long
    ) {
        val caption = message.optString("caption", "")
        val text = message.optString("text", "")
        val content = caption.ifBlank { text }

        // Определяем заголовок заметки
        val title = when {
            content.length > 50 -> content.take(50) + "..."
            content.isNotBlank() -> content.lines().first()
            else -> "Из Telegram ${java.time.LocalDateTime.now().let {
                "${it.dayOfMonth}.${it.monthValue}.${it.year} ${it.hour}:${"%02d".format(it.minute)}"
            }}"
        }

        // Создаём заметку
        val noteId = repository.createNote(
            title = title,
            content = content,
            tags = listOf("telegram"),
            telegramMessageId = messageId,
            telegramChatId = chatId
        )

        var attachmentCount = 0

        // Обрабатываем фото
        message.optJSONArray("photo")?.let { photos ->
            // Берём наибольшее по размеру фото
            val largest = photos.getJSONObject(photos.length() - 1)
            val fileId = largest.getString("file_id")
            downloadAndSaveFile(fileId, noteId, "photo_$messageId.jpg", "image/jpeg")
            attachmentCount++
        }

        // Обрабатываем документ/файл
        message.optJSONObject("document")?.let { doc ->
            val fileId = doc.getString("file_id")
            val fileName = doc.optString("file_name", "file_$messageId")
            val mimeType = doc.optString("mime_type", "application/octet-stream")
            downloadAndSaveFile(fileId, noteId, fileName, mimeType)
            attachmentCount++
        }

        // Обрабатываем аудио
        message.optJSONObject("audio")?.let { audio ->
            val fileId = audio.getString("file_id")
            val fileName = audio.optString("file_name", "audio_$messageId.mp3")
            downloadAndSaveFile(fileId, noteId, fileName, "audio/mpeg")
            attachmentCount++
        }

        // Обрабатываем видео
        message.optJSONObject("video")?.let { video ->
            val fileId = video.getString("file_id")
            val fileName = video.optString("file_name", "video_$messageId.mp4")
            downloadAndSaveFile(fileId, noteId, fileName, "video/mp4")
            attachmentCount++
        }

        // Обрабатываем голосовое
        message.optJSONObject("voice")?.let { voice ->
            val fileId = voice.getString("file_id")
            downloadAndSaveFile(fileId, noteId, "voice_$messageId.ogg", "audio/ogg")
            attachmentCount++
        }

        // Отправляем подтверждение
        val attachInfo = if (attachmentCount > 0) " + $attachmentCount вложение" else ""
        sendMessage(chatId, "✅ Сохранено как заметка$attachInfo!")

        // Показываем уведомление
        showNoteCreatedNotification(title, noteId)
    }

    /**
     * Скачиваем файл с серверов Telegram и сохраняем в заметку
     */
    private suspend fun downloadAndSaveFile(
        fileId: String,
        noteId: Long,
        fileName: String,
        mimeType: String
    ) {
        try {
            // 1. Получаем путь к файлу
            val fileInfoUrl = "https://api.telegram.org/bot$botToken/getFile?file_id=$fileId"
            val fileInfoResp = withContext(Dispatchers.IO) {
                client.newCall(Request.Builder().url(fileInfoUrl).build()).execute()
            }
            val fileInfoJson = JSONObject(fileInfoResp.body?.string() ?: return)
            val filePath = fileInfoJson.getJSONObject("result").getString("file_path")

            // 2. Скачиваем файл
            val downloadUrl = "https://api.telegram.org/file/bot$botToken/$filePath"
            val downloadResp = withContext(Dispatchers.IO) {
                client.newCall(Request.Builder().url(downloadUrl).build()).execute()
            }
            val bytes = downloadResp.body?.bytes() ?: return

            // 3. Сохраняем через репозиторий
            repository.addAttachmentFromBytes(
                noteId = noteId,
                bytes = bytes,
                fileName = fileName,
                mimeType = mimeType,
                telegramFileId = fileId
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to download file $fileId", e)
        }
    }

    /**
     * Отправить текстовое сообщение пользователю
     */
    private suspend fun sendMessage(chatId: Long, text: String) {
        try {
            val json = JSONObject().apply {
                put("chat_id", chatId)
                put("text", text)
                put("parse_mode", "Markdown")
            }
            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("https://api.telegram.org/bot$botToken/sendMessage")
                .post(body)
                .build()
            withContext(Dispatchers.IO) { client.newCall(request).execute() }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send message", e)
        }
    }

    private fun showNoteCreatedNotification(title: String, noteId: Long) {
        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra("open_note_id", noteId)
        }
        val pi = PendingIntent.getActivity(this, noteId.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notif = NotificationCompat.Builder(this, "notes_channel")
            .setSmallIcon(R.drawable.ic_note)
            .setContentTitle("Новая заметка из Telegram")
            .setContentText(title)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("notes_channel", "Новые заметки",
                NotificationManager.IMPORTANCE_DEFAULT)
        )
        nm.notify(System.currentTimeMillis().toInt(), notif)
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Telegram Bot",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Сервис получения заметок из Telegram"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(status: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NoteVault Bot")
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_telegram)
            .setOngoing(true)
            .build()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isPolling = false
        scope.cancel()
    }
}
