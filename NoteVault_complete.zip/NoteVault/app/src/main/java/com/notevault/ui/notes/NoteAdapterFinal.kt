package com.notevault.ui.notes

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.notevault.R
import com.notevault.data.local.entities.Note
import com.notevault.databinding.ItemNoteGridBinding
import com.notevault.databinding.ItemNoteListBinding
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

class NoteAdapter(
    private val onNoteClick: (Note) -> Unit,
    private val onNoteLongClick: (Note) -> Unit
) : ListAdapter<Note, RecyclerView.ViewHolder>(DiffCallback) {

    var currentViewMode = "grid"
        private set

    companion object {
        private const val TYPE_GRID = 0
        private const val TYPE_LIST = 1
        private val DATE_FMT = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)
    }

    fun setViewMode(mode: String) {
        if (currentViewMode == mode) return
        currentViewMode = mode
        notifyItemRangeChanged(0, itemCount)
    }

    override fun getItemViewType(position: Int) =
        if (currentViewMode == "grid") TYPE_GRID else TYPE_LIST

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_GRID)
            GridVH(ItemNoteGridBinding.inflate(inflater, parent, false))
        else
            ListVH(ItemNoteListBinding.inflate(inflater, parent, false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val note = getItem(position)
        when (holder) {
            is GridVH -> holder.bind(note)
            is ListVH -> holder.bind(note)
        }
    }

    // ─── Grid ViewHolder ─────────────────────────────────────────────────────
    inner class GridVH(private val b: ItemNoteGridBinding) :
        RecyclerView.ViewHolder(b.root) {

        fun bind(note: Note) {
            b.tvTitle.text   = note.title.ifBlank { "Без названия" }
            b.tvContent.text = note.content.take(200)
            b.tvDate.text    = note.updatedAt.format(DATE_FMT)
            b.ivPin.visibility = if (note.isPinned) View.VISIBLE else View.GONE
            b.tvTelegramBadge.visibility =
                if (note.telegramChatId != null) View.VISIBLE else View.GONE

            // Цвет карточки
            val typedArray = b.root.context.resources.obtainTypedArray(R.array.note_colors)
            val colorRes = typedArray.getResourceId(
                note.color.coerceIn(0, typedArray.length() - 1), 0
            )
            typedArray.recycle()
            if (colorRes != 0) {
                b.cardView.setCardBackgroundColor(
                    ContextCompat.getColor(b.root.context, colorRes)
                )
            }

            b.root.setOnClickListener { onNoteClick(note) }
            b.root.setOnLongClickListener { onNoteLongClick(note); true }
        }
    }

    // ─── List ViewHolder ─────────────────────────────────────────────────────
    inner class ListVH(private val b: ItemNoteListBinding) :
        RecyclerView.ViewHolder(b.root) {

        fun bind(note: Note) {
            b.tvTitle.text   = note.title.ifBlank { "Без названия" }
            b.tvContent.text = note.content.take(120)
            b.tvDate.text    = note.updatedAt.format(DATE_FMT)
            b.ivPin.visibility = if (note.isPinned) View.VISIBLE else View.GONE

            b.root.setOnClickListener { onNoteClick(note) }
            b.root.setOnLongClickListener { onNoteLongClick(note); true }
        }
    }

    object DiffCallback : DiffUtil.ItemCallback<Note>() {
        override fun areItemsTheSame(a: Note, b: Note) = a.id == b.id
        override fun areContentsTheSame(a: Note, b: Note) = a == b
    }
}
