package com.notevault.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.LocalDateTime

enum class AttachmentType {
    IMAGE,      // jpg, png, gif, webp
    VIDEO,      // mp4, avi, mov
    AUDIO,      // mp3, ogg, wav
    DOCUMENT,   // pdf, docx, xlsx
    FILE        // всё остальное
}

@Entity(
    tableName = "attachments",
    foreignKeys = [
        ForeignKey(
            entity = Note::class,
            parentColumns = ["id"],
            childColumns = ["noteId"],
            onDelete = ForeignKey.CASCADE  // удаление заметки — удаляет все вложения
        )
    ],
    indices = [Index("noteId")]
)
data class Attachment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val noteId: Long,
    val fileName: String,           // оригинальное имя файла
    val localPath: String,          // путь в internal storage
    val mimeType: String,
    val type: AttachmentType,
    val size: Long,                 // размер в байтах
    val width: Int? = null,         // для изображений
    val height: Int? = null,
    val thumbnailPath: String? = null,  // путь к превью
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val telegramFileId: String? = null  // file_id в Telegram
) {
    fun getReadableSize(): String {
        return when {
            size < 1024 -> "$size B"
            size < 1024 * 1024 -> "${size / 1024} KB"
            else -> "${"%.1f".format(size / (1024.0 * 1024.0))} MB"
        }
    }
}
