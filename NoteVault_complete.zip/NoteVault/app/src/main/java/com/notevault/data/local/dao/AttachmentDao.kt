package com.notevault.data.local.dao

import androidx.room.*
import com.notevault.data.local.entities.Attachment
import com.notevault.data.local.entities.AttachmentType
import kotlinx.coroutines.flow.Flow

@Dao
interface AttachmentDao {

    @Query("SELECT * FROM attachments WHERE noteId = :noteId ORDER BY createdAt ASC")
    fun getAttachmentsForNote(noteId: Long): Flow<List<Attachment>>

    @Query("SELECT * FROM attachments WHERE noteId = :noteId AND type = :type")
    fun getAttachmentsByType(noteId: Long, type: AttachmentType): Flow<List<Attachment>>

    @Query("SELECT * FROM attachments WHERE id = :id")
    suspend fun getAttachmentById(id: Long): Attachment?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachment(attachment: Attachment): Long

    @Delete
    suspend fun deleteAttachment(attachment: Attachment)

    @Query("DELETE FROM attachments WHERE noteId = :noteId")
    suspend fun deleteAllForNote(noteId: Long)

    @Query("SELECT SUM(size) FROM attachments")
    suspend fun getTotalStorageUsed(): Long?

    @Query("SELECT * FROM attachments WHERE type = :type ORDER BY createdAt DESC")
    fun getAllByType(type: AttachmentType): Flow<List<Attachment>>
}
