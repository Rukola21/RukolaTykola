package com.notevault.utils

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "notevault_prefs")

@Singleton
class AppPreferences @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val dataStore = context.dataStore

    companion object {
        val KEY_BOT_TOKEN = stringPreferencesKey("telegram_bot_token")
        val KEY_CHAT_ID = longPreferencesKey("telegram_chat_id")
        val KEY_LAST_UPDATE_ID = longPreferencesKey("last_update_id")
        val KEY_BOT_ENABLED = booleanPreferencesKey("bot_enabled")
        val KEY_THEME = stringPreferencesKey("theme")  // "system", "light", "dark"
        val KEY_NOTES_VIEW = stringPreferencesKey("notes_view")  // "grid", "list"
    }

    // Синхронное чтение (только для Service)
    var telegramBotToken: String
        get() = runBlocking { dataStore.data.map { it[KEY_BOT_TOKEN] ?: "" }.let { flow ->
            var value = ""
            runBlocking { flow.collect { value = it; return@collect } }
            value
        }}
        set(value) = runBlocking { dataStore.edit { it[KEY_BOT_TOKEN] = value } }

    var telegramChatId: Long
        get() = runBlocking { readLong(KEY_CHAT_ID) }
        set(value) = runBlocking { dataStore.edit { it[KEY_CHAT_ID] = value } }

    var lastUpdateId: Long
        get() = runBlocking { readLong(KEY_LAST_UPDATE_ID) }
        set(value) = runBlocking { dataStore.edit { it[KEY_LAST_UPDATE_ID] = value } }

    var botEnabled: Boolean
        get() = runBlocking { readBool(KEY_BOT_ENABLED) }
        set(value) = runBlocking { dataStore.edit { it[KEY_BOT_ENABLED] = value } }

    // Flow для реактивного чтения в ViewModel
    val botTokenFlow: Flow<String> = dataStore.data.map { it[KEY_BOT_TOKEN] ?: "" }
    val chatIdFlow: Flow<Long> = dataStore.data.map { it[KEY_CHAT_ID] ?: 0L }
    val botEnabledFlow: Flow<Boolean> = dataStore.data.map { it[KEY_BOT_ENABLED] ?: false }
    val themeFlow: Flow<String> = dataStore.data.map { it[KEY_THEME] ?: "system" }
    val notesViewFlow: Flow<String> = dataStore.data.map { it[KEY_NOTES_VIEW] ?: "grid" }

    suspend fun setBotToken(token: String) = dataStore.edit { it[KEY_BOT_TOKEN] = token }
    suspend fun setChatId(id: Long) = dataStore.edit { it[KEY_CHAT_ID] = id }
    suspend fun setBotEnabled(enabled: Boolean) = dataStore.edit { it[KEY_BOT_ENABLED] = enabled }
    suspend fun setTheme(theme: String) = dataStore.edit { it[KEY_THEME] = theme }
    suspend fun setNotesView(view: String) = dataStore.edit { it[KEY_NOTES_VIEW] = view }

    private suspend fun readLong(key: Preferences.Key<Long>): Long {
        var result = 0L
        dataStore.data.map { it[key] ?: 0L }.collect { result = it; return@collect }
        return result
    }

    private suspend fun readBool(key: Preferences.Key<Boolean>): Boolean {
        var result = false
        dataStore.data.map { it[key] ?: false }.collect { result = it; return@collect }
        return result
    }
}
