package com.notevault.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.notevault.data.local.dao.AttachmentDao
import com.notevault.data.local.dao.NoteDao
import com.notevault.data.local.entities.Attachment
import com.notevault.data.local.entities.AttachmentType
import com.notevault.data.local.entities.Note
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class Converters {
    private val formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME

    @TypeConverter
    fun fromDateTime(value: String?): LocalDateTime? =
        value?.let { LocalDateTime.parse(it, formatter) }

    @TypeConverter
    fun toDateTime(dateTime: LocalDateTime?): String? =
        dateTime?.format(formatter)

    @TypeConverter
    fun fromAttachmentType(type: AttachmentType): String = type.name

    @TypeConverter
    fun toAttachmentType(value: String): AttachmentType =
        AttachmentType.valueOf(value)
}

@Database(
    entities = [Note::class, Attachment::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class NoteDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun attachmentDao(): AttachmentDao
}
