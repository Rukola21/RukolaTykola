package com.notevault.ui.editor

import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notevault.data.local.entities.Attachment
import com.notevault.data.local.entities.Note
import com.notevault.data.repository.NoteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import javax.inject.Inject

sealed class EditorEvent {
    data class ShowError(val message: String) : EditorEvent()
    object NoteSaved : EditorEvent()
    object NoteDeleted : EditorEvent()
}

@HiltViewModel
class NoteEditorViewModel @Inject constructor(
    private val repository: NoteRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val noteId: Long = savedStateHandle["noteId"] ?: -1L

    private val _note = MutableStateFlow<Note?>(null)
    val note = _note.asStateFlow()

    val attachments: StateFlow<List<Attachment>> = if (noteId > 0) {
        repository.getAttachmentsForNote(noteId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    } else {
        MutableStateFlow(emptyList())
    }

    private val _events = MutableSharedFlow<EditorEvent>()
    val events = _events.asSharedFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving = _isSaving.asStateFlow()

    // Редактируемые поля
    val title = MutableStateFlow("")
    val content = MutableStateFlow("")
    val tags = MutableStateFlow<List<String>>(emptyList())

    init {
        if (noteId > 0) {
            viewModelScope.launch {
                val n = repository.getNoteById(noteId)
                _note.value = n
                n?.let {
                    title.value = it.title
                    content.value = it.content
                    tags.value = it.getTagsList()
                }
            }
        }
    }

    fun saveNote() {
        viewModelScope.launch {
            _isSaving.value = true
            try {
                val currentNote = _note.value
                if (currentNote == null) {
                    // Новая заметка
                    val id = repository.createNote(
                        title = title.value,
                        content = content.value,
                        tags = tags.value
                    )
                    _note.value = repository.getNoteById(id)
                } else {
                    // Обновление
                    repository.updateNote(currentNote.copy(
                        title = title.value,
                        content = content.value,
                        tags = tags.value.joinToString(",", "[", "]") { "\"$it\"" },
                        updatedAt = LocalDateTime.now()
                    ))
                }
                _events.emit(EditorEvent.NoteSaved)
            } catch (e: Exception) {
                _events.emit(EditorEvent.ShowError("Ошибка сохранения: ${e.message}"))
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun addAttachment(uri: Uri) {
        val noteId = _note.value?.id ?: return
        viewModelScope.launch {
            repository.addAttachmentFromUri(noteId, uri)
                ?: _events.emit(EditorEvent.ShowError("Не удалось прикрепить файл"))
        }
    }

    fun deleteAttachment(attachment: Attachment) {
        viewModelScope.launch {
            repository.deleteAttachment(attachment)
        }
    }

    fun addTag(tag: String) {
        val trimmed = tag.trim().lowercase()
        if (trimmed.isNotBlank() && !tags.value.contains(trimmed)) {
            tags.value = tags.value + trimmed
        }
    }

    fun removeTag(tag: String) {
        tags.value = tags.value - tag
    }

    fun deleteNote() {
        viewModelScope.launch {
            _note.value?.let {
                repository.deleteNote(it)
                _events.emit(EditorEvent.NoteDeleted)
            }
        }
    }
}
