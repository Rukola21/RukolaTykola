package com.notevault.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDateTime

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val tags: String = "",          // JSON array of tags: ["work","personal"]
    val isPinned: Boolean = false,
    val color: Int = 0,             // background color index (0=default)
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val updatedAt: LocalDateTime = LocalDateTime.now(),
    val telegramMessageId: Long? = null,  // ID сообщения из Telegram
    val telegramChatId: Long? = null
) {
    fun getTagsList(): List<String> {
        if (tags.isBlank()) return emptyList()
        return tags.removeSurrounding("[", "]")
            .split(",")
            .map { it.trim().removeSurrounding("\"") }
            .filter { it.isNotBlank() }
    }
}
