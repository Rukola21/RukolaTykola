package com.notevault.ui.editor

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.notevault.R
import com.notevault.data.local.entities.Attachment
import com.notevault.data.local.entities.AttachmentType
import com.notevault.databinding.ItemAttachmentBinding
import java.io.File

class AttachmentAdapter(
    private val onAttachmentClick: (Attachment) -> Unit,
    private val onAttachmentDelete: (Attachment) -> Unit
) : ListAdapter<Attachment, AttachmentAdapter.ViewHolder>(DiffCallback) {

    inner class ViewHolder(private val b: ItemAttachmentBinding) :
        RecyclerView.ViewHolder(b.root) {

        fun bind(attachment: Attachment) {
            when (attachment.type) {
                AttachmentType.IMAGE -> {
                    val thumb = attachment.thumbnailPath?.let { File(it) }
                        ?: File(attachment.localPath)
                    Glide.with(b.ivPreview)
                        .load(thumb)
                        .centerCrop()
                        .placeholder(R.drawable.ic_image_placeholder)
                        .into(b.ivPreview)
                    b.tvFileName.text = attachment.fileName
                    b.ivTypeIcon.setImageResource(R.drawable.ic_image)
                }
                AttachmentType.VIDEO -> {
                    b.ivPreview.setImageResource(R.drawable.ic_video)
                    b.tvFileName.text = attachment.fileName
                    b.ivTypeIcon.setImageResource(R.drawable.ic_video)
                }
                AttachmentType.AUDIO -> {
                    b.ivPreview.setImageResource(R.drawable.ic_audio)
                    b.tvFileName.text = attachment.fileName
                    b.ivTypeIcon.setImageResource(R.drawable.ic_audio)
                }
                AttachmentType.DOCUMENT -> {
                    b.ivPreview.setImageResource(R.drawable.ic_document)
                    b.tvFileName.text = attachment.fileName
                    b.ivTypeIcon.setImageResource(R.drawable.ic_document)
                }
                AttachmentType.FILE -> {
                    b.ivPreview.setImageResource(R.drawable.ic_file)
                    b.tvFileName.text = attachment.fileName
                    b.ivTypeIcon.setImageResource(R.drawable.ic_file)
                }
            }

            b.tvFileSize.text = attachment.getReadableSize()
            b.root.setOnClickListener { onAttachmentClick(attachment) }
            b.btnDelete.setOnClickListener { onAttachmentDelete(attachment) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemAttachmentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(getItem(position))

    object DiffCallback : DiffUtil.ItemCallback<Attachment>() {
        override fun areItemsTheSame(a: Attachment, b: Attachment) = a.id == b.id
        override fun areContentsTheSame(a: Attachment, b: Attachment) = a == b
    }
}
