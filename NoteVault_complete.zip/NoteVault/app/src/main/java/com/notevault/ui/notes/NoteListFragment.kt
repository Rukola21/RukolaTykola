package com.notevault.ui.notes

import android.os.Bundle
import android.view.*
import androidx.appcompat.widget.SearchView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.google.android.material.chip.Chip
import com.google.android.material.snackbar.Snackbar
import com.notevault.R
import com.notevault.data.local.entities.Note
import com.notevault.databinding.FragmentNoteListBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class NoteListFragment : Fragment() {

    private var _binding: FragmentNoteListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: NoteListViewModel by viewModels()
    private lateinit var adapter: NoteAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNoteListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupSearch()
        setupFab()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = NoteAdapter(
            onNoteClick = { note -> openNote(note) },
            onNoteLongClick = { note -> showNoteMenu(note) }
        )

        binding.recyclerView.adapter = adapter
        binding.recyclerView.setHasFixedSize(false)
        updateLayoutManager("grid")
    }

    private fun updateLayoutManager(mode: String) {
        binding.recyclerView.layoutManager = when (mode) {
            "list" -> androidx.recyclerview.widget.LinearLayoutManager(requireContext())
            else -> StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        }
        adapter.setViewMode(mode)
    }

    private fun setupSearch() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.search(newText ?: "")
                return true
            }
        })
    }

    private fun setupFab() {
        binding.fabNewNote.setOnClickListener {
            findNavController().navigate(
                NoteListFragmentDirections.actionListToEditor()
            )
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.notes.collect { notes ->
                        adapter.submitList(notes)
                        binding.emptyState.isVisible = notes.isEmpty()
                        binding.recyclerView.isVisible = notes.isNotEmpty()
                    }
                }
                launch {
                    viewModel.notesViewMode.collect { mode ->
                        updateLayoutManager(mode)
                        binding.btnToggleView.setImageResource(
                            if (mode == "grid") R.drawable.ic_list else R.drawable.ic_grid
                        )
                    }
                }
            }
        }
    }

    private fun openNote(note: Note) {
        findNavController().navigate(
            NoteListFragmentDirections.actionListToEditor(note.id)
        )
    }

    private fun showNoteMenu(note: Note) {
        val options = arrayOf(
            if (note.isPinned) "Открепить" else "Закрепить",
            "Удалить"
        )
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(note.title.ifBlank { "Заметка" })
            .setItems(options) { _, which ->
                when (which) {
                    0 -> viewModel.togglePin(note)
                    1 -> confirmDelete(note)
                }
            }
            .show()
    }

    private fun confirmDelete(note: Note) {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Удалить заметку?")
            .setMessage("Это действие нельзя отменить.")
            .setPositiveButton("Удалить") { _, _ ->
                viewModel.deleteNote(note)
                Snackbar.make(binding.root, "Заметка удалена", Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
