package com.notevault.ui.viewer

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notevault.data.local.entities.Attachment
import com.notevault.data.repository.NoteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class AttachmentViewerViewModel @Inject constructor(
    private val repository: NoteRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val noteId: Long = savedStateHandle["noteId"] ?: -1L

    val attachments: StateFlow<List<Attachment>> = repository
        .getAttachmentsForNote(noteId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedIndex = MutableStateFlow(0)

    val currentAttachment: StateFlow<Attachment?> = combine(attachments, _selectedIndex) { list, idx ->
        list.getOrNull(idx)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun selectAttachment(index: Int) { _selectedIndex.value = index }
}
