package com.notevault.utils

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences>
    by preferencesDataStore(name = "notevault_prefs")

@Singleton
class AppPreferences @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val dataStore = context.dataStore

    companion object {
        val KEY_BOT_TOKEN   = stringPreferencesKey("telegram_bot_token")
        val KEY_CHAT_ID     = longPreferencesKey("telegram_chat_id")
        val KEY_LAST_UPDATE = longPreferencesKey("last_update_id")
        val KEY_BOT_ENABLED = booleanPreferencesKey("bot_enabled")
        val KEY_THEME       = stringPreferencesKey("theme")
        val KEY_NOTES_VIEW  = stringPreferencesKey("notes_view")
    }

    // ── Synchronous reads (only for Service/BroadcastReceiver) ───────────────
    val telegramBotToken: String
        get() = runBlocking { dataStore.data.map { it[KEY_BOT_TOKEN] ?: "" }.first() }

    val telegramChatId: Long
        get() = runBlocking { dataStore.data.map { it[KEY_CHAT_ID] ?: 0L }.first() }

    var lastUpdateId: Long
        get() = runBlocking { dataStore.data.map { it[KEY_LAST_UPDATE] ?: 0L }.first() }
        set(v) = runBlocking { dataStore.edit { it[KEY_LAST_UPDATE] = v } }

    val botEnabled: Boolean
        get() = runBlocking { dataStore.data.map { it[KEY_BOT_ENABLED] ?: false }.first() }

    // ── Reactive Flows (use in ViewModel) ────────────────────────────────────
    val botTokenFlow: Flow<String>  = dataStore.data.map { it[KEY_BOT_TOKEN]   ?: "" }
    val chatIdFlow:   Flow<Long>    = dataStore.data.map { it[KEY_CHAT_ID]     ?: 0L }
    val botEnabledFlow: Flow<Boolean> = dataStore.data.map { it[KEY_BOT_ENABLED] ?: false }
    val themeFlow:    Flow<String>  = dataStore.data.map { it[KEY_THEME]       ?: "system" }
    val notesViewFlow: Flow<String> = dataStore.data.map { it[KEY_NOTES_VIEW]  ?: "grid" }

    // ── Suspend setters ───────────────────────────────────────────────────────
    suspend fun setBotToken(token: String)  = dataStore.edit { it[KEY_BOT_TOKEN]   = token }
    suspend fun setChatId(id: Long)         = dataStore.edit { it[KEY_CHAT_ID]     = id }
    suspend fun setBotEnabled(on: Boolean)  = dataStore.edit { it[KEY_BOT_ENABLED] = on }
    suspend fun setTheme(theme: String)     = dataStore.edit { it[KEY_THEME]       = theme }
    suspend fun setNotesView(view: String)  = dataStore.edit { it[KEY_NOTES_VIEW]  = view }
}
