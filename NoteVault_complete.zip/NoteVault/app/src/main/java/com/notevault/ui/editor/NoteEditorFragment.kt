package com.notevault.ui.editor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.provider.FontRequest
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.chip.Chip
import com.google.android.material.snackbar.Snackbar
import com.notevault.R
import com.notevault.databinding.FragmentNoteEditorBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class NoteEditorFragment : Fragment() {

    private var _binding: FragmentNoteEditorBinding? = null
    private val binding get() = _binding!!
    private val viewModel: NoteEditorViewModel by viewModels()
    private val args: NoteEditorFragmentArgs by navArgs()

    private lateinit var attachmentAdapter: AttachmentAdapter

    // Launcher для выбора файлов
    private val pickFileLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        uris.forEach { viewModel.addAttachment(it) }
    }

    // Launcher для камеры
    private var cameraUri: Uri? = null
    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) cameraUri?.let { viewModel.addAttachment(it) }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNoteEditorBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupAttachments()
        setupBottomBar()
        observeViewModel()
        handleSharedContent()
    }

    private fun setupAttachments() {
        attachmentAdapter = AttachmentAdapter(
            onAttachmentClick = { /* открыть просмотр */ },
            onAttachmentDelete = { viewModel.deleteAttachment(it) }
        )
        binding.rvAttachments.apply {
            adapter = attachmentAdapter
            layoutManager = GridLayoutManager(requireContext(), 3)
        }
    }

    private fun setupBottomBar() {
        binding.btnAttachImage.setOnClickListener {
            pickFileLauncher.launch("image/*")
        }
        binding.btnAttachFile.setOnClickListener {
            pickFileLauncher.launch("*/*")
        }
        binding.btnCamera.setOnClickListener {
            launchCamera()
        }
        binding.btnAddTag.setOnClickListener {
            showTagDialog()
        }
    }

    private fun launchCamera() {
        val photoFile = java.io.File.createTempFile(
            "photo_${System.currentTimeMillis()}", ".jpg",
            requireContext().cacheDir
        )
        cameraUri = androidx.core.content.FileProvider.getUriForFile(
            requireContext(),
            "${requireContext().packageName}.fileprovider",
            photoFile
        )
        cameraLauncher.launch(cameraUri)
    }

    private fun showTagDialog() {
        val input = com.google.android.material.textfield.TextInputEditText(requireContext())
        input.hint = "Введи тег"
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Добавить тег")
            .setView(input)
            .setPositiveButton("Добавить") { _, _ ->
                val tag = input.text?.toString() ?: return@setPositiveButton
                viewModel.addTag(tag)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {

                launch {
                    viewModel.note.collect { note ->
                        note?.let {
                            if (binding.etTitle.text.isNullOrEmpty())
                                binding.etTitle.setText(it.title)
                            if (binding.etContent.text.isNullOrEmpty())
                                binding.etContent.setText(it.content)
                        }
                    }
                }

                launch {
                    viewModel.attachments.collect { attachments ->
                        attachmentAdapter.submitList(attachments)
                        binding.rvAttachments.isVisible = attachments.isNotEmpty()
                    }
                }

                launch {
                    viewModel.tags.collect { tags ->
                        binding.chipGroupTags.removeAllViews()
                        tags.forEach { tag ->
                            val chip = Chip(requireContext()).apply {
                                text = tag
                                isCloseIconVisible = true
                                setOnCloseIconClickListener { viewModel.removeTag(tag) }
                            }
                            binding.chipGroupTags.addView(chip)
                        }
                    }
                }

                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is EditorEvent.NoteSaved -> {
                                Snackbar.make(binding.root, "Сохранено", Snackbar.LENGTH_SHORT).show()
                            }
                            is EditorEvent.NoteDeleted -> {
                                findNavController().popBackStack()
                            }
                            is EditorEvent.ShowError -> {
                                Snackbar.make(binding.root, event.message, Snackbar.LENGTH_LONG).show()
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Обработка Share Intent (когда приложение открыто через "Поделиться")
     */
    private fun handleSharedContent() {
        val activity = requireActivity()
        val intent = activity.intent
        if (intent?.action == Intent.ACTION_SEND) {
            when {
                intent.type == "text/plain" -> {
                    val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
                    sharedText?.let {
                        binding.etContent.setText(it)
                        binding.etTitle.setText(it.lines().first().take(50))
                    }
                }
                intent.type?.startsWith("image/") == true -> {
                    (intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { uri ->
                        // Сначала создаём заметку, потом добавляем вложение
                        viewModel.saveNote()
                        viewModel.addAttachment(uri)
                    }
                }
                else -> {
                    (intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { uri ->
                        viewModel.saveNote()
                        viewModel.addAttachment(uri)
                    }
                }
            }
            // Сбрасываем Intent, чтобы при повороте не обработать снова
            activity.intent = Intent()
        } else if (intent?.action == Intent.ACTION_SEND_MULTIPLE) {
            val uris = intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            uris?.forEach { uri ->
                viewModel.saveNote()
                viewModel.addAttachment(uri)
            }
            activity.intent = Intent()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_editor, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_save -> {
                viewModel.title.value = binding.etTitle.text.toString()
                viewModel.content.value = binding.etContent.text.toString()
                viewModel.saveNote()
                true
            }
            R.id.action_delete -> {
                confirmDelete()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun confirmDelete() {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Удалить заметку?")
            .setPositiveButton("Удалить") { _, _ -> viewModel.deleteNote() }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onPause() {
        super.onPause()
        // Автосохранение при уходе с экрана
        viewModel.title.value = binding.etTitle.text.toString()
        viewModel.content.value = binding.etContent.text.toString()
        if (viewModel.title.value.isNotBlank() || viewModel.content.value.isNotBlank()) {
            viewModel.saveNote()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
