package com.notevault.utils

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.notevault.data.local.dao.AttachmentDao
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Периодически удаляет файлы вложений, которые больше не привязаны ни к одной заметке.
 * Запускается раз в неделю.
 */
@HiltWorker
class CleanupWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val attachmentDao: AttachmentDao
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val allAttachments = attachmentDao.getAllAttachments()
            val validPaths = allAttachments.map { it.localPath }.toSet()

            val notesDir = File(applicationContext.filesDir, "notes")
            if (!notesDir.exists()) return Result.success()

            var deletedCount = 0
            notesDir.walkTopDown().forEach { file ->
                if (file.isFile && file.absolutePath !in validPaths) {
                    file.delete()
                    deletedCount++
                }
            }

            // Удаляем пустые директории
            notesDir.walkBottomUp().forEach { dir ->
                if (dir.isDirectory && dir.listFiles()?.isEmpty() == true && dir != notesDir) {
                    dir.delete()
                }
            }

            android.util.Log.i("CleanupWorker", "Cleaned up $deletedCount orphaned files")
            Result.success()
        } catch (e: Exception) {
            android.util.Log.e("CleanupWorker", "Cleanup failed", e)
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "NoteVault_Cleanup"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<CleanupWorker>(7, TimeUnit.DAYS)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiresBatteryNotLow(true)
                        .build()
                )
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}

// Добавь в AttachmentDao:
// @Query("SELECT * FROM attachments") suspend fun getAllAttachments(): List<Attachment>
