package com.notevault.telegram

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.notevault.utils.AppPreferences
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject
    lateinit var prefs: AppPreferences

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            if (prefs.botEnabled && prefs.telegramBotToken.isNotBlank()) {
                TelegramBotService.start(context)
            }
        }
    }
}
