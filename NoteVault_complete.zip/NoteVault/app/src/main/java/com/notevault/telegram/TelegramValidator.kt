package com.notevault.telegram

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

data class BotInfo(
    val id: Long,
    val firstName: String,
    val username: String
)

sealed class ValidationResult {
    data class Success(val botInfo: BotInfo) : ValidationResult()
    data class Error(val message: String) : ValidationResult()
}

@Singleton
class TelegramValidator @Inject constructor() {

    private val client = OkHttpClient()

    /**
     * Проверяем токен — вызываем getMe и парсим ответ
     */
    suspend fun validateToken(token: String): ValidationResult = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.telegram.org/bot${token.trim()}/getMe"
            val response = client.newCall(
                Request.Builder().url(url).build()
            ).execute()

            val body = response.body?.string()
                ?: return@withContext ValidationResult.Error("Пустой ответ от сервера")

            val json = JSONObject(body)

            if (!json.getBoolean("ok")) {
                val errDesc = json.optString("description", "Неизвестная ошибка")
                return@withContext ValidationResult.Error(
                    when {
                        errDesc.contains("Unauthorized") -> "Неверный токен. Проверь токен от @BotFather"
                        else -> errDesc
                    }
                )
            }

            val result = json.getJSONObject("result")
            ValidationResult.Success(
                BotInfo(
                    id = result.getLong("id"),
                    firstName = result.getString("first_name"),
                    username = result.optString("username", "")
                )
            )
        } catch (e: java.net.UnknownHostException) {
            ValidationResult.Error("Нет подключения к интернету")
        } catch (e: Exception) {
            ValidationResult.Error("Ошибка: ${e.message}")
        }
    }
}
