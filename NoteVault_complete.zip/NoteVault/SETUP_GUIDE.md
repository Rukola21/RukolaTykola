# NoteVault — Руководство по сборке и запуску

## Что сделано

Полная кодовая база Android-приложения для заметок с интеграцией Telegram.

---

## Структура проекта

```
NoteVault/
├── build.gradle                         ← корневой build файл
├── settings.gradle                      ← настройки Gradle
├── app/
│   ├── build.gradle                     ← зависимости приложения
│   └── src/main/
│       ├── AndroidManifest.xml          ← permissions, activities, services
│       ├── java/com/notevault/
│       │   ├── NoteVaultApp.kt          ← Application class (Hilt)
│       │   ├── data/
│       │   │   ├── local/
│       │   │   │   ├── entities/
│       │   │   │   │   ├── Note.kt      ← Room entity заметки
│       │   │   │   │   └── Attachment.kt← Room entity вложения
│       │   │   │   ├── dao/
│       │   │   │   │   ├── NoteDao.kt   ← DAO для заметок
│       │   │   │   │   └── AttachmentDao.kt
│       │   │   │   └── NoteDatabase.kt  ← Room database
│       │   │   └── repository/
│       │   │       └── NoteRepository.kt← единая точка доступа к данным
│       │   ├── di/
│       │   │   └── AppModule.kt         ← Hilt DI module
│       │   ├── ui/
│       │   │   ├── MainActivity.kt      ← Host activity + Navigation
│       │   │   ├── notes/
│       │   │   │   ├── NoteListFragment.kt    ← список заметок
│       │   │   │   ├── NoteListViewModel.kt
│       │   │   │   └── NoteAdapter.kt         ← grid/list адаптер
│       │   │   ├── editor/
│       │   │   │   ├── NoteEditorFragment.kt  ← редактор заметки
│       │   │   │   ├── NoteEditorViewModel.kt
│       │   │   │   └── AttachmentAdapter.kt   ← вложения
│       │   │   └── settings/
│       │   │       ├── SettingsFragment.kt    ← настройки + Telegram
│       │   │       └── SettingsViewModel.kt
│       │   ├── telegram/
│       │   │   ├── TelegramBotService.kt  ← Foreground Service, polling API
│       │   │   └── BootReceiver.kt        ← автозапуск после перезагрузки
│       │   └── utils/
│       │       ├── FileUtils.kt           ← работа с файлами
│       │       └── AppPreferences.kt      ← DataStore preferences
│       └── res/
│           ├── layout/         ← XML layouts
│           ├── navigation/     ← nav_graph.xml
│           ├── menu/           ← bottom nav, editor menus
│           ├── values/         ← strings, colors, themes, arrays
│           └── xml/            ← file_paths для FileProvider
```

---

## Запуск проекта в Android Studio

### 1. Открыть проект
```
File → Open → выбери папку NoteVault
```

### 2. Добавить Safe Args плагин
В **корневой** `build.gradle` добавь:
```groovy
id 'androidx.navigation.safeargs.kotlin' version '2.7.6' apply false
```
В `app/build.gradle`:
```groovy
id 'androidx.navigation.safeargs.kotlin'
```

### 3. Добавить vector drawables
Создай векторные иконки в `res/drawable/` (или используй Material Icons):
- `ic_add.xml`       — плюс (FAB)
- `ic_note.xml`      — заметка
- `ic_notes.xml`     — список заметок (bottom nav)
- `ic_settings.xml`  — настройки
- `ic_telegram.xml`  — логотип Telegram
- `ic_pin.xml`       — булавка
- `ic_save.xml`      — сохранить
- `ic_delete.xml`    — удалить
- `ic_image.xml`     — изображение
- `ic_attach.xml`    — скрепка
- `ic_camera.xml`    — камера
- `ic_tag.xml`       — тег
- `ic_grid.xml`      — сетка
- `ic_list.xml`      — список
- `ic_copy.xml`      — копировать
- `ic_file.xml`      — файл
- `ic_video.xml`     — видео
- `ic_audio.xml`     — аудио
- `ic_document.xml`  — документ
- `ic_close.xml`     — крестик
- `ic_chevron_right.xml`
- `ic_empty_notes.xml`
- `ic_image_placeholder.xml`

**Быстрый способ**: используй Android Studio встроенный Vector Asset Studio:
`Right click res/drawable → New → Vector Asset → Clip Art → выбери иконку из Material Icons`

### 4. Добавить `ic_launcher` иконку
Используй `res/mipmap-hdpi/ic_launcher.png` или создай через:
`Right click res → New → Image Asset`

### 5. Sync и Run
```
File → Sync Project with Gradle Files
Run → Run 'app'
```

---

## Настройка Telegram бота

### Пошагово

1. **Создать бота** — открой [@BotFather](https://t.me/BotFather) в Telegram
2. **Отправь** `/newbot`
3. **Придумай имя** например `MyNoteVault Bot`
4. **Придумай username** например `mynote_vault_bot`
5. **Скопируй токен** — выглядит так: `6428391234:AAF3mK...`
6. В приложении: **Настройки → Telegram Бот → вставь токен → Сохранить**
7. **Включи переключатель** "Бот активен"
8. **Напиши боту `/start`** — Chat ID сохранится автоматически
9. Теперь **пересылай** боту любые сообщения из Telegram!

### Как пересылать из Telegram

В любом чате нажми и удержи сообщение → **"Переслать"** → выбери своего бота.
Можно пересылать:
- Текстовые сообщения
- Фотографии
- Голосовые сообщения
- Видео
- Документы и файлы
- Альбомы из нескольких фото

### Как работает интеграция

```
Пользователь                    Telegram            NoteVault App
     │                              │                     │
     │── пересылает фото ──────────>│                     │
     │                              │<── getUpdates ──────│  (каждые 2 сек)
     │                              │─── update JSON ────>│
     │                              │                     │── создаёт Note
     │                              │                     │── скачивает файл
     │                              │                     │── сохраняет в Room
     │<── ✅ "Сохранено как заметка!"│<───────────────────│
     │                              │                     │── уведомление
```

---

## Share Intent из других приложений

Из любого Android-приложения:
- Chrome: поделиться ссылкой → NoteVault
- Telegram: поделиться текстом/файлом → NoteVault (без бота)
- Галерея: поделиться фото → NoteVault
- Файловый менеджер: поделиться документом → NoteVault

---

## Возможности для расширения

| Функция | Как добавить |
|---------|-------------|
| Markdown preview | Markwon уже в зависимостях |
| Синхронизация в облако | Firebase Firestore / Google Drive API |
| Напоминания по заметкам | AlarmManager + WorkManager |
| Шифрование заметок | Android Keystore + SQLCipher |
| Виджет на рабочий стол | AppWidget API |
| Голосовые заметки | MediaRecorder |
| OCR из изображений | ML Kit Text Recognition |
| Экспорт в PDF | PdfDocument API |

---

## Технические детали

**Telegram Bot API** используется через long polling:
- `getUpdates?offset={id}&timeout=30` — ждём обновления
- `getFile` — получаем путь к файлу
- `https://api.telegram.org/file/bot{token}/{path}` — скачиваем файл
- `sendMessage` — отправляем подтверждение пользователю

**Хранение файлов**: все вложения сохраняются в `context.filesDir/notes/note_{id}/`
Файлы доступны только приложению (Internal Storage), не видны другим приложениям.

**Автозапуск**: `BootReceiver` запускает `TelegramBotService` при перезагрузке устройства.
