# NoteVault — Android Notes App with Telegram Integration

## Архитектура приложения

```
NoteVault/
├── app/src/main/java/com/notevault/
│   ├── data/
│   │   ├── local/
│   │   │   ├── entities/     → Room entities (Note, Attachment)
│   │   │   ├── dao/          → DAO интерфейсы
│   │   │   └── NoteDatabase.kt
│   │   └── repository/       → NoteRepository
│   ├── di/                   → Hilt модули
│   ├── ui/
│   │   ├── notes/            → Список заметок (NoteListFragment)
│   │   ├── editor/           → Редактор заметок (NoteEditorFragment)
│   │   ├── settings/         → Настройки (SettingsFragment)
│   │   └── bot/              → Настройка Telegram бота
│   ├── telegram/             → TelegramBotService
│   └── utils/                → FileUtils, ImageUtils
└── res/
```

## Стек технологий

| Компонент | Технология |
|-----------|-----------|
| Архитектура | MVVM + Clean Architecture |
| DI | Hilt |
| БД | Room |
| Async | Coroutines + Flow |
| UI | Material Design 3 |
| Изображения | Glide |
| Telegram | TelegramBots Java Library |
| Файлы | FileProvider + SAF |

## Возможности

- 📝 Текстовые заметки с Markdown
- 🖼️ Прикрепление изображений (камера / галерея)
- 📎 Прикрепление любых файлов
- 🤖 Telegram бот — пересылка сообщений, фото, файлов прямо в заметки
- 🔍 Поиск по заметкам
- 🏷️ Теги / категории
- 📤 Шеринг из других приложений (Share target)
- 🌙 Тёмная тема

## Настройка Telegram бота

1. Открой @BotFather в Telegram
2. `/newbot` → задай имя и username
3. Скопируй токен
4. В приложении: Настройки → Telegram бот → вставь токен
5. Напиши боту `/start` — получишь свой Chat ID
6. Теперь пересылай боту любые сообщения/фото/файлы — они сохранятся в NoteVault!
