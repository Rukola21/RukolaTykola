package com.notevault.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notevault.data.repository.NoteRepository
import com.notevault.telegram.TelegramValidator
import com.notevault.telegram.ValidationResult
import com.notevault.utils.AppPreferences
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class SettingsEvent {
    data class TokenSaved(val botName: String) : SettingsEvent()
    data class Error(val message: String) : SettingsEvent()
    object TokenCleared : SettingsEvent()
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val prefs: AppPreferences,
    private val repository: NoteRepository,
    private val validator: TelegramValidator
) : ViewModel() {

    val botToken: StateFlow<String> = prefs.botTokenFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    val chatId: StateFlow<Long> = prefs.chatIdFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val botEnabled: StateFlow<Boolean> = prefs.botEnabledFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val _isValidating = MutableStateFlow(false)
    val isValidating = _isValidating.asStateFlow()

    private val _events = MutableSharedFlow<SettingsEvent>()
    val events = _events.asSharedFlow()

    val storageUsed: StateFlow<Long> = flow {
        emit(repository.getTotalStorageUsed())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    fun saveAndValidateBotToken(token: String) {
        viewModelScope.launch {
            _isValidating.value = true
            try {
                when (val result = validator.validateToken(token)) {
                    is ValidationResult.Success -> {
                        prefs.setBotToken(token.trim())
                        _events.emit(SettingsEvent.TokenSaved(
                            "@${result.botInfo.username} (${result.botInfo.firstName})"
                        ))
                    }
                    is ValidationResult.Error -> {
                        _events.emit(SettingsEvent.Error(result.message))
                    }
                }
            } catch (e: Exception) {
                _events.emit(SettingsEvent.Error("Ошибка: ${e.message}"))
            } finally {
                _isValidating.value = false
            }
        }
    }

    fun setBotEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setBotEnabled(enabled) }
    }
}
