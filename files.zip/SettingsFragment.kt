package com.notevault.ui.settings

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.snackbar.Snackbar
import com.notevault.databinding.FragmentSettingsBinding
import com.notevault.telegram.TelegramBotService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupBotSection()
        observeViewModel()
    }

    private fun setupBotSection() {
        binding.btnSaveToken.setOnClickListener {
            val token = binding.etBotToken.text.toString().trim()
            if (token.isBlank()) {
                binding.tilBotToken.error = "Введи токен бота"
                return@setOnClickListener
            }
            binding.tilBotToken.error = null
            binding.btnSaveToken.isEnabled = false
            binding.btnSaveToken.text = "Проверяю..."
            viewModel.saveAndValidateBotToken(token)
        }

        binding.btnOpenBotFather.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW,
                android.net.Uri.parse("https://t.me/BotFather")))
        }

        binding.switchBotEnabled.setOnCheckedChangeListener { _, isChecked ->
            val token = viewModel.botToken.value
            if (isChecked && token.isBlank()) {
                binding.switchBotEnabled.isChecked = false
                Snackbar.make(binding.root, "Сначала введи токен бота", Snackbar.LENGTH_LONG).show()
                return@setOnCheckedChangeListener
            }
            viewModel.setBotEnabled(isChecked)
            if (isChecked) {
                TelegramBotService.start(requireContext())
            } else {
                TelegramBotService.stop(requireContext())
            }
        }

        binding.btnCopyChatId.setOnClickListener {
            val chatId = binding.tvChatId.text.toString()
            val clipboard = requireContext()
                .getSystemService(android.content.ClipboardManager::class.java)
            clipboard.setPrimaryClip(
                android.content.ClipData.newPlainText("Chat ID", chatId)
            )
            Snackbar.make(binding.root, "Chat ID скопирован", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {

                launch {
                    viewModel.botToken.collect { token ->
                        if (token.isNotBlank() && binding.etBotToken.text.isNullOrEmpty()) {
                            binding.etBotToken.setText("••••••" + token.takeLast(4))
                        }
                    }
                }

                launch {
                    viewModel.chatId.collect { id ->
                        binding.tvChatId.text = if (id == 0L)
                            "Не получен — напиши боту /start"
                        else
                            id.toString()
                        binding.btnCopyChatId.isEnabled = id != 0L
                    }
                }

                launch {
                    viewModel.botEnabled.collect { enabled ->
                        // Обновляем без тригера listener
                        binding.switchBotEnabled.setOnCheckedChangeListener(null)
                        binding.switchBotEnabled.isChecked = enabled
                        binding.tvBotStatus.text = if (enabled) "🟢 Бот активен" else "⚫ Бот выключен"
                        binding.switchBotEnabled.setOnCheckedChangeListener { _, isChecked ->
                            val token = viewModel.botToken.value
                            if (isChecked && token.isBlank()) {
                                binding.switchBotEnabled.isChecked = false
                                Snackbar.make(binding.root, "Сначала введи токен бота", Snackbar.LENGTH_LONG).show()
                                return@setOnCheckedChangeListener
                            }
                            viewModel.setBotEnabled(isChecked)
                            if (isChecked) TelegramBotService.start(requireContext())
                            else TelegramBotService.stop(requireContext())
                        }
                    }
                }

                launch {
                    viewModel.isValidating.collect { validating ->
                        binding.btnSaveToken.isEnabled = !validating
                        binding.btnSaveToken.text = if (validating) "Проверяю..." else "Сохранить токен"
                    }
                }

                launch {
                    viewModel.storageUsed.collect { bytes ->
                        binding.tvStorageUsed.text = formatBytes(bytes)
                    }
                }

                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is SettingsEvent.TokenSaved -> {
                                Snackbar.make(
                                    binding.root,
                                    "✅ Подключён: ${event.botName}",
                                    Snackbar.LENGTH_LONG
                                ).show()
                            }
                            is SettingsEvent.Error -> {
                                Snackbar.make(binding.root, "❌ ${event.message}", Snackbar.LENGTH_LONG).show()
                            }
                            is SettingsEvent.TokenCleared -> {
                                binding.etBotToken.setText("")
                                Snackbar.make(binding.root, "Токен удалён", Snackbar.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1048576 -> "${bytes / 1024} KB"
        else -> "${"%.1f".format(bytes / 1048576.0)} MB"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
