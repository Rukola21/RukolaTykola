package com.notevault.telegram

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.notevault.R
import com.notevault.data.repository.NoteRepository
import com.notevault.ui.MainActivity
import com.notevault.utils.AppPreferences
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@AndroidEntryPoint
class TelegramBotService : Service() {

    @Inject lateinit var repository: NoteRepository
    @Inject lateinit var prefs: AppPreferences

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private var botToken = ""
    private var allowedChatId = 0L
    private var isPolling = false
    private val mediaGroupBuffer = mutableMapOf<String, Long>()

    companion object {
        const val CHANNEL_ID    = "tg_bot_service"
        const val NOTES_CHANNEL = "notes_incoming"
        const val NOTIF_ID      = 9001
        private const val TAG   = "TGBotService"

        fun start(context: Context) {
            try {
                context.startForegroundService(Intent(context, TelegramBotService::class.java))
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start service", e)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, TelegramBotService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildServiceNotif("Подключение..."))

        // Читаем настройки в IO потоке чтобы не блокировать main thread
        scope.launch {
            botToken      = prefs.telegramBotToken
            allowedChatId = prefs.telegramChatId

            if (botToken.isBlank()) {
                Log.w(TAG, "No bot token, stopping")
                withContext(Dispatchers.Main) { stopSelf() }
                return@launch
            }

            updateNotif("Слушаю Telegram...")
            startPolling()
        }

        return START_STICKY
    }

    private fun startPolling() {
        if (isPolling) return
        isPolling = true
        scope.launch {
            Log.i(TAG, "Polling started")
            while (isPolling && botToken.isNotBlank()) {
                try {
                    poll()
                } catch (e: CancellationException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Poll error: ${e.message}")
                    delay(5_000)
                }
                delay(2_000)
            }
        }
    }

    private suspend fun poll() {
        val offset = prefs.lastUpdateId + 1
        val url = "https://api.telegram.org/bot$botToken/getUpdates?offset=$offset&timeout=30&limit=10"
        val body = get(url) ?: return
        val json = JSONObject(body)
        if (!json.getBoolean("ok")) return
        val updates = json.getJSONArray("result")
        for (i in 0 until updates.length()) {
            val upd = updates.getJSONObject(i)
            prefs.lastUpdateId = upd.getLong("update_id")
            processUpdate(upd)
        }
    }

    private suspend fun processUpdate(update: JSONObject) {
        val msg = update.optJSONObject("message") ?: return
        val chatId = msg.getJSONObject("chat").getLong("id")
        val msgId  = msg.getLong("message_id")
        val text   = msg.optString("text", "")

        if (allowedChatId != 0L && chatId != allowedChatId) {
            send(chatId, "⛔ Нет доступа.")
            return
        }

        when {
            text.startsWith("/start") -> handleStart(chatId)
            text.startsWith("/help")  -> handleHelp(chatId)
            text.startsWith("/list")  -> handleList(chatId)
            else -> handleContent(msg, chatId, msgId)
        }
    }

    private suspend fun handleStart(chatId: Long) {
        if (allowedChatId == 0L) {
            prefs.setChatId(chatId)
            allowedChatId = chatId
        }
        send(chatId, "✅ *NoteVault Bot активирован!*\n\nПересылай мне что угодно — всё сохранится как заметка.\n\n/help — справка")
    }

    private suspend fun handleHelp(chatId: Long) {
        send(chatId, "📒 *NoteVault Bot*\n\nПришли:\n• Текст → заметка\n• Фото → заметка + фото\n• Файл → заметка + вложение\n• Голосовое → заметка + аудио\n\n/list — последние заметки")
    }

    private suspend fun handleList(chatId: Long) {
        val notes = repository.getRecentNotes(5)
        if (notes.isEmpty()) { send(chatId, "📭 Заметок нет."); return }
        val sb = StringBuilder("📋 *Последние заметки:*\n\n")
        notes.forEachIndexed { i, n ->
            sb.appendLine("${i + 1}. ${n.title.ifBlank { n.content.take(40) }}")
        }
        send(chatId, sb.toString())
    }

    private suspend fun handleContent(msg: JSONObject, chatId: Long, msgId: Long) {
        val caption = msg.optString("caption", "")
        val text    = msg.optString("text", "")
        val body    = caption.ifBlank { text }

        val tags = Regex("#(\\w+)").findAll(body)
            .map { it.groupValues[1].lowercase() }
            .toMutableList().also { it.add("telegram") }

        val mediaGroupId = msg.optString("media_group_id", "")
        val noteId: Long = if (mediaGroupId.isNotEmpty() && mediaGroupBuffer.containsKey(mediaGroupId)) {
            mediaGroupBuffer[mediaGroupId]!!
        } else {
            val title = body.lines().firstOrNull { it.isNotBlank() }?.take(60) ?: "Из Telegram #$msgId"
            val id = repository.createNote(
                title = title,
                content = body,
                tags = tags,
                telegramMessageId = msgId,
                telegramChatId = chatId
            )
            if (mediaGroupId.isNotEmpty()) mediaGroupBuffer[mediaGroupId] = id
            id
        }

        var attached = 0

        msg.optJSONArray("photo")?.let { photos ->
            val best = photos.getJSONObject(photos.length() - 1)
            downloadFile(best.getString("file_id"), noteId, "photo_$msgId.jpg", "image/jpeg")
            attached++
        }
        msg.optJSONObject("document")?.let { doc ->
            downloadFile(doc.getString("file_id"), noteId,
                doc.optString("file_name", "file_$msgId"),
                doc.optString("mime_type", "application/octet-stream"))
            attached++
        }
        msg.optJSONObject("audio")?.let { a ->
            downloadFile(a.getString("file_id"), noteId,
                a.optString("file_name", "audio_$msgId.mp3"), "audio/mpeg")
            attached++
        }
        msg.optJSONObject("voice")?.let { v ->
            downloadFile(v.getString("file_id"), noteId, "voice_$msgId.ogg", "audio/ogg")
            attached++
        }
        msg.optJSONObject("video")?.let { v ->
            downloadFile(v.getString("file_id"), noteId,
                v.optString("file_name", "video_$msgId.mp4"), "video/mp4")
            attached++
        }

        val suffix = if (attached > 0) " + $attached вложение" else ""
        send(chatId, "✅ Сохранено$suffix!")
        showNoteNotification("Из Telegram", noteId)
    }

    private suspend fun downloadFile(fileId: String, noteId: Long, fileName: String, mime: String) {
        try {
            val info = JSONObject(get("https://api.telegram.org/bot$botToken/getFile?file_id=$fileId") ?: return)
            if (!info.getBoolean("ok")) return
            val path = info.getJSONObject("result").getString("file_path")
            val bytes = getRaw("https://api.telegram.org/file/bot$botToken/$path") ?: return
            repository.addAttachmentFromBytes(noteId, bytes, fileName, mime, fileId)
        } catch (e: Exception) {
            Log.e(TAG, "Download failed: $fileId", e)
        }
    }

    private suspend fun get(url: String): String? = withContext(Dispatchers.IO) {
        try {
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (r.isSuccessful) r.body?.string() else null
            }
        } catch (e: Exception) { Log.e(TAG, "GET failed: $url", e); null }
    }

    private suspend fun getRaw(url: String): ByteArray? = withContext(Dispatchers.IO) {
        try {
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (r.isSuccessful) r.body?.bytes() else null
            }
        } catch (e: Exception) { null }
    }

    private suspend fun send(chatId: Long, text: String) {
        try {
            val body = JSONObject().apply {
                put("chat_id", chatId)
                put("text", text)
                put("parse_mode", "Markdown")
            }.toString().toRequestBody("application/json".toMediaType())
            withContext(Dispatchers.IO) {
                client.newCall(Request.Builder()
                    .url("https://api.telegram.org/bot$botToken/sendMessage")
                    .post(body).build()).execute().close()
            }
        } catch (e: Exception) { Log.e(TAG, "Send failed", e) }
    }

    private fun showNoteNotification(title: String, noteId: Long) {
        val pi = PendingIntent.getActivity(this, noteId.toInt(),
            Intent(this, MainActivity::class.java).apply {
                putExtra("open_note_id", noteId)
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        getSystemService(NotificationManager::class.java).notify(
            noteId.toInt(),
            NotificationCompat.Builder(this, NOTES_CHANNEL)
                .setSmallIcon(R.drawable.ic_telegram)
                .setContentTitle("Новая заметка из Telegram")
                .setContentText(title)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
        )
    }

    private fun updateNotif(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildServiceNotif(text))
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(
            CHANNEL_ID, "Telegram Bot", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Фоновый сервис NoteVault" })
        nm.createNotificationChannel(NotificationChannel(
            NOTES_CHANNEL, "Входящие заметки", NotificationManager.IMPORTANCE_DEFAULT
        ))
    }

    private fun buildServiceNotif(status: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NoteVault Bot")
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_telegram)
            .setOngoing(true)
            .setSilent(true)
            .build()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isPolling = false
        scope.cancel()
    }
}
