package com.notevault.utils

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "notevault_prefs")

@Singleton
class AppPreferences @Inject constructor(
    @ApplicationContext private val context: Context
) {
    val dataStore = context.dataStore

    companion object {
        val KEY_BOT_TOKEN   = stringPreferencesKey("telegram_bot_token")
        val KEY_CHAT_ID     = longPreferencesKey("telegram_chat_id")
        val KEY_LAST_UPDATE = longPreferencesKey("last_update_id")
        val KEY_BOT_ENABLED = booleanPreferencesKey("bot_enabled")
        val KEY_NOTES_VIEW  = stringPreferencesKey("notes_view")
    }

    // Только для Service — вызывать только из фонового потока
    val telegramBotToken: String
        get() = try {
            runBlocking {
                dataStore.data.catch { emit(emptyPreferences()) }
                    .map { it[KEY_BOT_TOKEN] ?: "" }.first()
            }
        } catch (e: Exception) { "" }

    val telegramChatId: Long
        get() = try {
            runBlocking {
                dataStore.data.catch { emit(emptyPreferences()) }
                    .map { it[KEY_CHAT_ID] ?: 0L }.first()
            }
        } catch (e: Exception) { 0L }

    var lastUpdateId: Long
        get() = try {
            runBlocking {
                dataStore.data.catch { emit(emptyPreferences()) }
                    .map { it[KEY_LAST_UPDATE] ?: 0L }.first()
            }
        } catch (e: Exception) { 0L }
        set(v) { try { runBlocking { dataStore.edit { it[KEY_LAST_UPDATE] = v } } } catch (e: Exception) {} }

    val botEnabled: Boolean
        get() = try {
            runBlocking {
                dataStore.data.catch { emit(emptyPreferences()) }
                    .map { it[KEY_BOT_ENABLED] ?: false }.first()
            }
        } catch (e: Exception) { false }

    // Flows для ViewModel
    val botTokenFlow: Flow<String> = dataStore.data
        .catch { emit(emptyPreferences()) }.map { it[KEY_BOT_TOKEN] ?: "" }

    val chatIdFlow: Flow<Long> = dataStore.data
        .catch { emit(emptyPreferences()) }.map { it[KEY_CHAT_ID] ?: 0L }

    val botEnabledFlow: Flow<Boolean> = dataStore.data
        .catch { emit(emptyPreferences()) }.map { it[KEY_BOT_ENABLED] ?: false }

    val notesViewFlow: Flow<String> = dataStore.data
        .catch { emit(emptyPreferences()) }.map { it[KEY_NOTES_VIEW] ?: "grid" }

    // Suspend setters
    suspend fun setBotToken(token: String)  = dataStore.edit { it[KEY_BOT_TOKEN]   = token }
    suspend fun setChatId(id: Long)         = dataStore.edit { it[KEY_CHAT_ID]     = id }
    suspend fun setBotEnabled(on: Boolean)  = dataStore.edit { it[KEY_BOT_ENABLED] = on }
    suspend fun setNotesView(view: String)  = dataStore.edit { it[KEY_NOTES_VIEW]  = view }
}
