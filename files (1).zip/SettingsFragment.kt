package com.notevault.ui.settings

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.snackbar.Snackbar
import com.notevault.databinding.FragmentSettingsBinding
import com.notevault.telegram.TelegramBotService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()

    // Запрос разрешения на уведомления (Android 13+)
    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startBot()
        else Snackbar.make(binding.root,
            "Без уведомлений бот не сможет работать в фоне", Snackbar.LENGTH_LONG).show()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupBotSection()
        observeViewModel()
    }

    private fun setupBotSection() {
        binding.btnSaveToken.setOnClickListener {
            val token = binding.etBotToken.text.toString().trim()
            if (token.isBlank()) {
                binding.tilBotToken.error = "Введи токен бота"
                return@setOnClickListener
            }
            binding.tilBotToken.error = null
            viewModel.saveAndValidateBotToken(token)
        }

        binding.btnOpenBotFather.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/BotFather")))
        }

        binding.switchBotEnabled.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                val token = viewModel.botToken.value
                if (token.isBlank()) {
                    binding.switchBotEnabled.isChecked = false
                    Snackbar.make(binding.root, "Сначала введи и сохрани токен", Snackbar.LENGTH_LONG).show()
                    return@setOnCheckedChangeListener
                }
                viewModel.setBotEnabled(true)
                checkNotifPermAndStartBot()
            } else {
                viewModel.setBotEnabled(false)
                TelegramBotService.stop(requireContext())
            }
        }

        binding.btnCopyChatId.setOnClickListener {
            val id = binding.tvChatId.text.toString()
            val cb = requireContext().getSystemService(android.content.ClipboardManager::class.java)
            cb.setPrimaryClip(android.content.ClipData.newPlainText("Chat ID", id))
            Snackbar.make(binding.root, "Скопировано", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun checkNotifPermAndStartBot() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                requireContext(), Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        startBot()
    }

    private fun startBot() {
        TelegramBotService.start(requireContext())
        Snackbar.make(binding.root, "Бот запущен", Snackbar.LENGTH_SHORT).show()
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {

                launch {
                    viewModel.botToken.collect { token ->
                        if (token.isNotBlank() && binding.etBotToken.text.isNullOrEmpty()) {
                            binding.etBotToken.setText("••••••" + token.takeLast(4))
                        }
                    }
                }

                launch {
                    viewModel.chatId.collect { id ->
                        binding.tvChatId.text = if (id == 0L)
                            "Напиши боту /start чтобы получить ID"
                        else id.toString()
                        binding.btnCopyChatId.isEnabled = id != 0L
                    }
                }

                launch {
                    viewModel.botEnabled.collect { enabled ->
                        binding.switchBotEnabled.setOnCheckedChangeListener(null)
                        binding.switchBotEnabled.isChecked = enabled
                        binding.tvBotStatus.text = if (enabled) "🟢 Бот активен" else "⚫ Бот выключен"
                        binding.switchBotEnabled.setOnCheckedChangeListener { _, isChecked ->
                            if (isChecked) {
                                val token = viewModel.botToken.value
                                if (token.isBlank()) {
                                    binding.switchBotEnabled.isChecked = false
                                    Snackbar.make(binding.root, "Сначала введи токен", Snackbar.LENGTH_LONG).show()
                                    return@setOnCheckedChangeListener
                                }
                                viewModel.setBotEnabled(true)
                                checkNotifPermAndStartBot()
                            } else {
                                viewModel.setBotEnabled(false)
                                TelegramBotService.stop(requireContext())
                            }
                        }
                    }
                }

                launch {
                    viewModel.isValidating.collect { validating ->
                        binding.btnSaveToken.isEnabled = !validating
                        binding.btnSaveToken.text = if (validating) "Проверяю..." else "Сохранить токен"
                    }
                }

                launch {
                    viewModel.storageUsed.collect { bytes ->
                        binding.tvStorageUsed.text = when {
                            bytes < 1024       -> "$bytes B"
                            bytes < 1_048_576  -> "${bytes / 1024} KB"
                            else               -> "${"%.1f".format(bytes / 1_048_576.0)} MB"
                        }
                    }
                }

                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is SettingsEvent.TokenSaved ->
                                Snackbar.make(binding.root,
                                    "✅ Подключён: ${event.botName}", Snackbar.LENGTH_LONG).show()
                            is SettingsEvent.Error ->
                                Snackbar.make(binding.root,
                                    "❌ ${event.message}", Snackbar.LENGTH_LONG).show()
                            is SettingsEvent.TokenCleared -> {
                                binding.etBotToken.setText("")
                                Snackbar.make(binding.root, "Токен удалён", Snackbar.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
