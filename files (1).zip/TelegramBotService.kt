package com.notevault.telegram

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.notevault.R
import com.notevault.data.repository.NoteRepository
import com.notevault.ui.MainActivity
import com.notevault.utils.AppPreferences
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@AndroidEntryPoint
class TelegramBotService : Service() {

    @Inject lateinit var repository: NoteRepository
    @Inject lateinit var prefs: AppPreferences

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .build()

    private var botToken = ""
    private var allowedChatId = 0L
    private var isPolling = false

    companion object {
        private const val CHANNEL_ID    = "tg_bot_service"
        private const val NOTES_CHANNEL = "notes_incoming"
        private const val NOTIF_ID      = 9001
        private const val TAG           = "TGBotService"

        fun start(context: Context) {
            try {
                val intent = Intent(context, TelegramBotService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start service: ${e.message}")
            }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, TelegramBotService::class.java))
            } catch (e: Exception) {
                Log.e(TAG, "Failed to stop service: ${e.message}")
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
        // Вызываем startForeground сразу в onCreate — обязательно для Android 12+
        startForegroundCompat()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        scope.launch {
            try {
                botToken      = prefs.telegramBotToken
                allowedChatId = prefs.telegramChatId

                if (botToken.isBlank()) {
                    Log.w(TAG, "No token — stopping")
                    withContext(Dispatchers.Main) { stopSelf() }
                    return@launch
                }

                updateNotif("Слушаю Telegram...")
                startPolling()
            } catch (e: Exception) {
                Log.e(TAG, "Init error: ${e.message}")
                withContext(Dispatchers.Main) { stopSelf() }
            }
        }
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val notification = buildNotif("Запуск...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                NOTIF_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun startPolling() {
        if (isPolling) return
        isPolling = true
        scope.launch {
            while (isPolling) {
                try {
                    poll()
                } catch (e: CancellationException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Poll error: ${e.message}")
                    delay(5_000)
                }
                delay(2_000)
            }
        }
    }

    private suspend fun poll() {
        val url = "https://api.telegram.org/bot$botToken/getUpdates" +
            "?offset=${prefs.lastUpdateId + 1}&timeout=30&limit=10"
        val body = get(url) ?: return
        val json = JSONObject(body)
        if (!json.getBoolean("ok")) return
        val updates = json.getJSONArray("result")
        for (i in 0 until updates.length()) {
            val upd = updates.getJSONObject(i)
            prefs.lastUpdateId = upd.getLong("update_id")
            processUpdate(upd)
        }
    }

    private suspend fun processUpdate(update: JSONObject) {
        val msg    = update.optJSONObject("message") ?: return
        val chatId = msg.getJSONObject("chat").getLong("id")
        val msgId  = msg.getLong("message_id")
        val text   = msg.optString("text", "")

        if (allowedChatId != 0L && chatId != allowedChatId) {
            send(chatId, "⛔ Нет доступа.")
            return
        }

        when {
            text.startsWith("/start") -> {
                if (allowedChatId == 0L) {
                    prefs.setChatId(chatId)
                    allowedChatId = chatId
                }
                send(chatId, "✅ *NoteVault Bot активирован!*\nПересылай мне что угодно — сохранится как заметка.\n/help — справка")
            }
            text.startsWith("/help") ->
                send(chatId, "📒 Пришли текст, фото, файл или голосовое — сохранится как заметка.")
            text.startsWith("/list") -> {
                val notes = repository.getRecentNotes(5)
                if (notes.isEmpty()) { send(chatId, "📭 Заметок нет."); return }
                send(chatId, notes.mapIndexed { i, n ->
                    "${i+1}. ${n.title.ifBlank { n.content.take(40) }}"
                }.joinToString("\n", "📋 *Последние заметки:*\n\n"))
            }
            else -> handleContent(msg, chatId, msgId)
        }
    }

    private suspend fun handleContent(msg: JSONObject, chatId: Long, msgId: Long) {
        val body  = msg.optString("caption", "").ifBlank { msg.optString("text", "") }
        val tags  = Regex("#(\\w+)").findAll(body)
            .map { it.groupValues[1].lowercase() }.toMutableList()
        tags.add("telegram")
        val title = body.lines().firstOrNull { it.isNotBlank() }?.take(60) ?: "Telegram #$msgId"

        val noteId = repository.createNote(
            title = title, content = body, tags = tags,
            telegramMessageId = msgId, telegramChatId = chatId
        )

        var attached = 0
        msg.optJSONArray("photo")?.let {
            downloadFile(it.getJSONObject(it.length()-1).getString("file_id"),
                noteId, "photo_$msgId.jpg", "image/jpeg"); attached++ }
        msg.optJSONObject("document")?.let {
            downloadFile(it.getString("file_id"), noteId,
                it.optString("file_name", "file_$msgId"),
                it.optString("mime_type", "application/octet-stream")); attached++ }
        msg.optJSONObject("audio")?.let {
            downloadFile(it.getString("file_id"), noteId,
                it.optString("file_name", "audio_$msgId.mp3"), "audio/mpeg"); attached++ }
        msg.optJSONObject("voice")?.let {
            downloadFile(it.getString("file_id"), noteId,
                "voice_$msgId.ogg", "audio/ogg"); attached++ }
        msg.optJSONObject("video")?.let {
            downloadFile(it.getString("file_id"), noteId,
                it.optString("file_name", "video_$msgId.mp4"), "video/mp4"); attached++ }

        send(chatId, "✅ Сохранено${if (attached > 0) " + $attached вл." else ""}!")
        showNoteNotif(title, noteId)
    }

    private suspend fun downloadFile(fileId: String, noteId: Long, name: String, mime: String) {
        try {
            val info = JSONObject(get(
                "https://api.telegram.org/bot$botToken/getFile?file_id=$fileId") ?: return)
            if (!info.getBoolean("ok")) return
            val path  = info.getJSONObject("result").getString("file_path")
            val bytes = getRaw("https://api.telegram.org/file/bot$botToken/$path") ?: return
            repository.addAttachmentFromBytes(noteId, bytes, name, mime, fileId)
        } catch (e: Exception) { Log.e(TAG, "Download failed: ${e.message}") }
    }

    private suspend fun get(url: String): String? = withContext(Dispatchers.IO) {
        try { client.newCall(Request.Builder().url(url).build())
            .execute().use { if (it.isSuccessful) it.body?.string() else null }
        } catch (e: Exception) { null }
    }

    private suspend fun getRaw(url: String): ByteArray? = withContext(Dispatchers.IO) {
        try { client.newCall(Request.Builder().url(url).build())
            .execute().use { if (it.isSuccessful) it.body?.bytes() else null }
        } catch (e: Exception) { null }
    }

    private suspend fun send(chatId: Long, text: String) {
        try {
            val body = JSONObject().apply {
                put("chat_id", chatId); put("text", text); put("parse_mode", "Markdown")
            }.toString().toRequestBody("application/json".toMediaType())
            withContext(Dispatchers.IO) {
                client.newCall(Request.Builder()
                    .url("https://api.telegram.org/bot$botToken/sendMessage")
                    .post(body).build()).execute().close()
            }
        } catch (e: Exception) { Log.e(TAG, "Send failed: ${e.message}") }
    }

    private fun showNoteNotif(title: String, noteId: Long) {
        val pi = PendingIntent.getActivity(this, noteId.toInt(),
            Intent(this, MainActivity::class.java).putExtra("open_note_id", noteId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        getSystemService(NotificationManager::class.java).notify(noteId.toInt(),
            NotificationCompat.Builder(this, NOTES_CHANNEL)
                .setSmallIcon(R.drawable.ic_telegram)
                .setContentTitle("Новая заметка из Telegram")
                .setContentText(title)
                .setContentIntent(pi).setAutoCancel(true).build())
    }

    private fun updateNotif(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotif(text))
    }

    private fun buildNotif(text: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NoteVault Bot").setContentText(text)
            .setSmallIcon(R.drawable.ic_telegram)
            .setOngoing(true).setSilent(true).build()

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(
            CHANNEL_ID, "Telegram Bot", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(
            NOTES_CHANNEL, "Входящие заметки", NotificationManager.IMPORTANCE_DEFAULT))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isPolling = false
        scope.cancel()
    }
}
